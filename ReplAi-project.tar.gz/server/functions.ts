import { Request, Response } from "express";
import { storage } from "./storage";
import crypto from "crypto";
import { sendAutoReplyNotification, sendNewReviewNotification, shouldNotify, sendAdminAIErrorNotification } from "./telegram";
import { getPlanById } from "@shared/subscriptionPlans";

const WB_FEEDBACKS_URL = "https://feedbacks-api.wildberries.ru";
const WB_CHAT_BASE = "https://buyer-chat-api.wildberries.ru";

const cabinetSyncLocks = new Map<string, Promise<any>>();

async function withConcurrencyLimit<T>(items: T[], limit: number, fn: (item: T) => Promise<void>): Promise<void> {
  const executing = new Set<Promise<void>>();
  for (const item of items) {
    const p = fn(item).then(() => { executing.delete(p); });
    executing.add(p);
    if (executing.size >= limit) {
      await Promise.race(executing);
    }
  }
  await Promise.all(executing);
}

async function checkAndResetSubscriptionPeriod(userId: string) {
  const sub = await storage.getUserSubscription(userId);
  if (!sub) return null;
  if (sub.currentPeriodEnd && new Date(sub.currentPeriodEnd) < new Date()) {
    await storage.updateSubscription(sub.id, { status: "expired" });
    return null;
  }
  return sub;
}

async function canSendReply(userId: string): Promise<{ allowed: boolean; subscriptionId?: string; useLegacy: boolean; error?: string }> {
  const sub = await checkAndResetSubscriptionPeriod(userId);
  if (sub) {
    const plan = getPlanById(sub.planId);
    if (!plan) return { allowed: false, useLegacy: true };
    if (plan.replyLimit === -1) return { allowed: true, subscriptionId: sub.id, useLegacy: false };
    if ((sub.repliesUsedThisPeriod || 0) < plan.replyLimit) return { allowed: true, subscriptionId: sub.id, useLegacy: false };
    return { allowed: false, useLegacy: false, error: `Лимит ответов исчерпан (${sub.repliesUsedThisPeriod}/${plan.replyLimit}). Обновите тариф или дождитесь нового периода.` };
  }
  const balance = await storage.getTokenBalance(userId);
  if (balance < 1) return { allowed: false, useLegacy: true, error: "Недостаточно токенов. Пополните баланс." };
  return { allowed: true, useLegacy: true };
}

async function hasPhotoAnalysisAccess(userId: string): Promise<boolean> {
  const sub = await storage.getUserSubscription(userId);
  return !!(sub && sub.photoAnalysisEnabled);
}

async function hasAiAnalystAccess(userId: string): Promise<boolean> {
  const sub = await storage.getUserSubscription(userId);
  return !!(sub && sub.aiAnalystEnabled);
}

const REFUSAL_KEYWORDS = [
  "отказ", "вернул", "вернула", "возврат",
  "не выкупил", "не выкупила", "не забрал", "не забрала",
  "отдал предпочтение", "отдала предпочтение",
  "не подошёл", "не подошла", "не подошло", "не подошел",
  "отправил обратно", "отправила обратно",
  "выбрал другой", "выбрала другую", "выбрала другой",
];

function buildFullPrompt(
  basePrompt: string,
  examples: string | null,
  rules: string | null,
  rulesDo: string | null = null,
  rulesDont: string | null = null,
  examplesV2: string | null = null,
  reviewRating: number = 0,
): string {
  let prompt = basePrompt;

  if (rulesDo && rulesDo.trim()) {
    prompt += `\n\nОБЯЗАТЕЛЬНЫЕ ПРАВИЛА:\n${rulesDo.trim()}`;
  }
  if (rulesDont && rulesDont.trim()) {
    prompt += `\n\nЗАПРЕЩЕНО:\n${rulesDont.trim()}`;
  }
  if (!rulesDo && !rulesDont && rules && rules.trim()) {
    prompt += `\n\nПРАВИЛА:\n${rules.trim()}`;
  }

  const ratingExamples = selectExamplesByRating(examplesV2, reviewRating);
  if (ratingExamples) {
    prompt += `\n\nПРИМЕРЫ ИДЕАЛЬНЫХ ОТВЕТОВ:\n${ratingExamples}`;
  } else if (examples && examples.trim()) {
    prompt += `\n\nПРИМЕРЫ ХОРОШИХ ОТВЕТОВ:\n${examples.trim()}`;
  }

  return prompt;
}

function selectExamplesByRating(examplesV2Json: string | null, rating: number): string | null {
  if (!examplesV2Json) return null;
  try {
    const parsed = JSON.parse(examplesV2Json);
    if (!Array.isArray(parsed) || parsed.length === 0) return null;

    const matched = parsed.filter((ex: any) => {
      if (!ex.text) return false;
      if (!ex.rating) return true;
      return ex.rating === rating;
    });

    if (matched.length === 0) {
      const fallback = parsed.filter((ex: any) => ex.text).slice(0, 3);
      if (fallback.length === 0) return null;
      return fallback.map((ex: any, i: number) => `${i + 1}. ${ex.text}`).join("\n\n");
    }

    return matched.slice(0, 3).map((ex: any, i: number) => `${i + 1}. ${ex.text}`).join("\n\n");
  } catch {
    return null;
  }
}

function detectRefusal(text?: string | null, pros?: string | null, cons?: string | null): boolean {
  const combined = [text, pros, cons].filter(Boolean).join(" ").toLowerCase();
  return REFUSAL_KEYWORDS.some((kw) => combined.includes(kw));
}

function delay(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function md5(str: string): string {
  return crypto.createHash("md5").update(str).digest("hex");
}

function buildReviewText(text?: string | null, pros?: string | null, cons?: string | null): string {
  const parts: string[] = [];
  if (text) parts.push(`Комментарий: ${text}`);
  if (pros) parts.push(`Плюсы: ${pros}`);
  if (cons) parts.push(`Недостатки: ${cons}`);
  return parts.length > 0 ? parts.join("\n\n") : "";
}

async function fetchWBReviews(apiKey: string, skip = 0, take = 50) {
  const url = `${WB_FEEDBACKS_URL}/api/v1/feedbacks?isAnswered=false&take=${take}&skip=${skip}`;
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 15000);
  try {
    const resp = await fetch(url, { headers: { Authorization: apiKey }, signal: controller.signal });
    if (!resp.ok) {
      const text = await resp.text();
      console.error(`[wb-api] fetchWBReviews error: status=${resp.status} url=${url} body=${text.slice(0, 500)}`);
      throw new Error(`WB API error ${resp.status}: ${text}`);
    }
    return resp.json();
  } finally {
    clearTimeout(timeout);
  }
}

async function fetchWBArchiveReviews(apiKey: string, skip = 0, take = 50) {
  const url = `${WB_FEEDBACKS_URL}/api/v1/feedbacks?isAnswered=true&take=${take}&skip=${skip}`;
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 15000);
  try {
    const resp = await fetch(url, { headers: { Authorization: apiKey }, signal: controller.signal });
    if (!resp.ok) {
      const text = await resp.text();
      console.error(`[wb-api] fetchWBArchiveReviews error: status=${resp.status} url=${url} body=${text.slice(0, 500)}`);
      throw new Error(`WB Archive API error ${resp.status}: ${text}`);
    }
    return resp.json();
  } finally {
    clearTimeout(timeout);
  }
}

async function fetchWBFeedbackById(apiKey: string, feedbackId: string) {
  const url = `${WB_FEEDBACKS_URL}/api/v1/feedback?id=${feedbackId}`;
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 15000);
  try {
    const resp = await fetch(url, { headers: { Authorization: apiKey }, signal: controller.signal });
    if (!resp.ok) {
      const text = await resp.text();
      console.error(`[wb-api] fetchWBFeedbackById error: status=${resp.status} id=${feedbackId} body=${text.slice(0, 500)}`);
      throw new Error(`WB API feedback error ${resp.status}: ${text}`);
    }
    return resp.json();
  } finally {
    clearTimeout(timeout);
  }
}

async function sendWBAnswer(apiKey: string, feedbackId: string, text: string) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 15000);
  try {
    const resp = await fetch(`${WB_FEEDBACKS_URL}/api/v1/feedbacks/answer`, {
      method: "POST",
      headers: { Authorization: apiKey, "Content-Type": "application/json" },
      body: JSON.stringify({ id: feedbackId, text }),
      signal: controller.signal,
    });
    if (!resp.ok) {
      const body = await resp.text();
      console.error(`[wb-api] sendWBAnswer error: status=${resp.status} feedbackId=${feedbackId} body=${body.slice(0, 500)}`);
      throw new Error(`WB answer error ${resp.status}: ${body}`);
    }
    return resp;
  } finally {
    clearTimeout(timeout);
  }
}

async function generateAIReply(
  apiKey: string, systemPrompt: string, reviewText: string, rating: number,
  productName: string, photoCount = 0, hasVideo = false, authorName = "",
  isEmpty = false, recommendationInstruction = "", isRefusal = false, brandName = "",
  photoLinks: any[] = [], photoAnalysisEnabled = false
) {
  let emptyInstruction = "";
  if (isEmpty) {
    emptyInstruction = rating >= 4
      ? `\n\n[Это пустой отзыв. Оценка ${rating}/5. КОРОТКАЯ благодарность, 1-2 предложения.]`
      : `\n\n[Это пустой отзыв. Оценка ${rating}/5. Сожаление + предложи написать в чат. 1-2 предложения.]`;
  }

  let attachmentInfo = "";
  if (photoCount > 0 || hasVideo) {
    const parts: string[] = [];
    if (photoCount > 0) {
      const photoWord = photoCount === 1 ? "фотографию" : photoCount < 5 ? "фотографии" : "фотографий";
      parts.push(`${photoCount} ${photoWord}`);
    }
    if (hasVideo) parts.push("видео");
    attachmentInfo = photoCount > 0 && photoAnalysisEnabled && photoLinks.length > 0
      ? `\n\n[Покупатель приложил ${parts.join(" и ")} к отзыву. Фотографии прикреплены ниже.\nПРАВИЛА АНАЛИЗА ФОТО:\n- Кратко упомяни что видно на фото (например: "Спасибо за фото, видим что товар выглядит отлично!" или "Благодарим за фото")\n- НЕ делай выводов о браке, дефектах или проблемах по фото — качество снимков может быть низким\n- Если на фото товар выглядит хорошо — отметь это положительно\n- Если покупатель в тексте жалуется на проблему — отвечай на текст, а не интерпретируй фото\n- Будь осторожен: блики, тени, сжатие фото могут искажать реальный вид товара]`
      : `\n\n[Покупатель приложил ${parts.join(" и ")}.]`;
  }

  const nameInstruction = authorName && authorName !== "Покупатель"
    ? `\n\nИмя покупателя: ${authorName}. Обратись по имени.` : "";

  const refusalWarning = isRefusal
    ? `\n\n[ВНИМАНИЕ: Покупатель НЕ выкупил товар. НЕ благодари за покупку.]` : "";

  const brandInstruction = brandName
    ? `\n\nБренд: ${brandName}. Используй в ответе.` : "";

  const userMessage = `ВАЖНО: следуй правилам промпта.${refusalWarning}${brandInstruction}\n\nОтзыв (${rating}/5) на "${productName}":\n\n${reviewText || "(Без текста)"}${attachmentInfo}${nameInstruction}${recommendationInstruction}${emptyInstruction}`;

  const hasPhotos = photoCount > 0 && photoAnalysisEnabled && photoLinks.length > 0;

  const primaryModel = hasPhotos
    ? "openai/gpt-4o"
    : rating >= 4
      ? "google/gemini-2.0-flash-001"
      : "openai/gpt-4o";

  const fallbackModels = hasPhotos
    ? ["google/gemini-2.0-flash-001", "anthropic/claude-3.5-sonnet"]
    : primaryModel === "google/gemini-2.0-flash-001"
      ? ["openai/gpt-4o", "anthropic/claude-3.5-sonnet"]
      : ["google/gemini-2.0-flash-001", "anthropic/claude-3.5-sonnet"];

  const modelsToTry = [primaryModel, ...fallbackModels];

  const userContent: any = hasPhotos
    ? [
        { type: "text", text: userMessage },
        ...photoLinks.slice(0, 5).map((photo: any) => ({
          type: "image_url",
          image_url: { url: photo.miniSize || photo.fullSize },
        })).filter((p: any) => p.image_url.url),
      ]
    : userMessage;

  const validPhotoCount = hasPhotos ? (userContent as any[]).filter((c: any) => c.type === "image_url").length : 0;
  console.log(`[ai-generate] model=${primaryModel} photos=${photoCount} photosSent=${validPhotoCount} product="${productName}" rating=${rating}`);

  let lastError: Error | null = null;

  for (const model of modelsToTry) {
    try {
      const resp = await fetch("https://openrouter.ai/api/v1/chat/completions", {
        method: "POST",
        headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          model,
          messages: [
            { role: "system", content: systemPrompt },
            { role: "user", content: hasPhotos && model !== "openai/gpt-4o" ? userMessage : userContent },
          ],
          max_tokens: isEmpty ? 300 : 1000,
          temperature: 0.7,
        }),
      });

      if (!resp.ok) {
        const text = await resp.text();
        console.warn(`[ai-fallback] Model ${model} failed (${resp.status}): ${text.slice(0, 200)}`);
        lastError = new Error(`AI gateway error ${resp.status}: ${text}`);
        continue;
      }

      const data = await resp.json();
      const result = data.choices?.[0]?.message?.content || "";
      if (!result) {
        console.warn(`[ai-fallback] Model ${model} returned empty response`);
        lastError = new Error(`Model ${model} returned empty response`);
        continue;
      }
      if (model !== primaryModel) {
        console.log(`[ai-fallback] Used fallback model ${model} (primary ${primaryModel} was unavailable)`);
      }
      return result;
    } catch (e: any) {
      console.warn(`[ai-fallback] Model ${model} error: ${e.message}`);
      lastError = e;
      continue;
    }
  }

  throw lastError || new Error("All AI models failed");
}

async function processCabinetReviews(
  cabinet: { id: string; userId: string; wbApiKey: string | null; aiPromptTemplate: string | null; replyModes: any; brandName: string | null },
  openrouterKey: string
) {
  const userId = cabinet.userId;
  const cabinetId = cabinet.id;
  const WB_API_KEY = cabinet.wbApiKey!;
  const defaultModes: Record<string, string> = { "1": "manual", "2": "manual", "3": "manual", "4": "manual", "5": "manual" };

  let cabinetModes = cabinet.replyModes as Record<string, string> | null;
  if (!cabinetModes || Object.keys(cabinetModes).length === 0) {
    const userSettings = await storage.getSettings(userId);
    cabinetModes = (userSettings?.replyModes as Record<string, string>) || null;
  }
  const replyModes = (cabinetModes && Object.keys(cabinetModes).length > 0) ? cabinetModes : defaultModes;

  let currentBalance = await storage.getTokenBalance(userId);
  const replyAccess = await canSendReply(userId);
  const [globalPrompt, globalExamples, globalRules, globalRulesDo, globalRulesDont, globalExamplesV2] = await Promise.all([
    storage.getGlobalSetting("default_prompt"),
    storage.getGlobalSetting("response_examples"),
    storage.getGlobalSetting("rules"),
    storage.getGlobalSetting("rules_do"),
    storage.getGlobalSetting("rules_dont"),
    storage.getGlobalSetting("response_examples_v2"),
  ]);
  const basePrompt = cabinet.aiPromptTemplate || globalPrompt ||
    "Ты — менеджер бренда на Wildberries. Напиши вежливый ответ на отзыв покупателя. 2-4 предложения.";

  console.log(`[sync-reviews] cabinet=${cabinetId} replyModes=${JSON.stringify(replyModes)} balance=${currentBalance}`);

  const allFeedbacks: any[] = [];
  let skip = 0;
  const take = 50;
  const MAX_UNANSWERED_PAGES = 20;
  const MAX_ANSWERED_PAGES = 5;
  try {
    let page = 0;
    while (page < MAX_UNANSWERED_PAGES) {
      console.log(`[sync-reviews] cabinet=${cabinetId} fetching unanswered page=${page} skip=${skip}`);
      const wbData = await fetchWBReviews(WB_API_KEY, skip, take);
      const feedbacks = wbData?.data?.feedbacks || [];
      if (feedbacks.length === 0) break;
      allFeedbacks.push(...feedbacks);
      if (feedbacks.length < take) break;
      skip += take;
      page++;
      await delay(350);
    }
    await storage.updateCabinetApiStatus(cabinetId, "connected_ok");
  } catch (e: any) {
    console.error(`[sync-reviews] cabinet=${cabinetId} Failed to fetch unanswered reviews: ${e.message}`);
    if (e.message?.includes("401")) {
      await storage.updateCabinetApiStatus(cabinetId, "error_401");
    }
  }

  const answeredFeedbacks: any[] = [];
  let skipAnswered = 0;
  try {
    let page = 0;
    while (page < MAX_ANSWERED_PAGES) {
      console.log(`[sync-reviews] cabinet=${cabinetId} fetching answered page=${page} skip=${skipAnswered}`);
      const wbData = await fetchWBArchiveReviews(WB_API_KEY, skipAnswered, take);
      const feedbacks = wbData?.data?.feedbacks || [];
      if (feedbacks.length === 0) break;
      answeredFeedbacks.push(...feedbacks);
      if (feedbacks.length < take) break;
      skipAnswered += take;
      page++;
      await delay(350);
    }
  } catch (e: any) {
    console.error(`[sync-reviews] cabinet=${cabinetId} Failed to fetch answered reviews: ${e.message}`);
  }

  console.log(`[sync-reviews] cabinet=${cabinetId} user=${userId} Fetched ${allFeedbacks.length} unanswered + ${answeredFeedbacks.length} answered reviews`);

  let newCount = 0;
  let autoSentCount = 0;
  let importedAnswered = 0;
  const errors: string[] = [];

  const allUnansweredWbIds = allFeedbacks.map((fb: any) => fb.id).filter(Boolean);
  const existingUnansweredIds = await storage.getExistingReviewWbIds(allUnansweredWbIds, userId, cabinetId);

  const newFeedbacks = allFeedbacks.filter((fb: any) => !existingUnansweredIds.has(fb.id));

  const photoAnalysisEnabled = newFeedbacks.length > 0 ? await hasPhotoAnalysisAccess(cabinet.userId) : false;

  const AI_BATCH = 5;
  const aiDrafts = new Map<string, string>();
  for (let i = 0; i < newFeedbacks.length; i += AI_BATCH) {
    const batch = newFeedbacks.slice(i, i + AI_BATCH);
    const results = await Promise.allSettled(
      batch.map(async (fb: any) => {
        const photoLinks = fb.photoLinks || [];
        const hasVideo = !!(fb.video && (fb.video.link || fb.video.previewImage));
        const isEmptyReview = !fb.text && !fb.pros && !fb.cons;
        const productArticle = String(fb.productDetails?.nmId || fb.nmId || "");
        const rating = fb.productValuation || 5;
        let recommendationInstruction = "";
        if (productArticle && rating >= 4) {
          const recommendations = await storage.getRecommendationsByArticle(productArticle, cabinetId);
          if (recommendations && recommendations.length > 0) {
            const recList = recommendations
              .map((r: any) => `- Артикул ${r.targetArticle}${r.targetName ? `: "${r.targetName}"` : ""}`)
              .join("\n");
            recommendationInstruction = `\n\nРЕКОМЕНДАЦИИ: В конце ответа ненавязчиво предложи покупателю обратить внимание на другие наши товары:\n${recList}\nУпомяни артикулы, чтобы покупатель мог их найти на WB.`;
          }
        }
        const reviewBrandName = fb.productDetails?.brandName || "";
        const effectiveBrand = reviewBrandName || cabinet.brandName || "";
        const isRefusal = detectRefusal(fb.text, fb.pros, fb.cons);
        const promptTemplate = buildFullPrompt(basePrompt, globalExamples, globalRules, globalRulesDo, globalRulesDont, globalExamplesV2, rating);
        const draft = await generateAIReply(
          openrouterKey, promptTemplate,
          buildReviewText(fb.text, fb.pros, fb.cons),
          rating,
          fb.productDetails?.productName || fb.subjectName || "Товар",
          photoLinks.length, hasVideo, fb.userName || "",
          isEmptyReview, recommendationInstruction, isRefusal, effectiveBrand,
          photoLinks, photoAnalysisEnabled
        );
        return { wbId: fb.id, draft };
      })
    );
    for (let j = 0; j < results.length; j++) {
      const r = results[j];
      if (r.status === "fulfilled" && r.value.draft) {
        aiDrafts.set(r.value.wbId, r.value.draft);
      } else if (r.status === "rejected") {
        const fb = batch[j];
        console.error(`AI generation failed for ${fb.id}:`, r.reason?.message);
        errors.push(`AI error for ${fb.id}: ${r.reason?.message}`);
      }
    }
    if (i + AI_BATCH < newFeedbacks.length) await delay(200);
  }

  for (const fb of newFeedbacks) {
    const wbId = fb.id;
    const photoLinks = fb.photoLinks || [];
    const hasVideo = !!(fb.video && (fb.video.link || fb.video.previewImage));
    const rating = fb.productValuation || 5;
    const reviewBrandName = fb.productDetails?.brandName || "";
    const aiDraft = aiDrafts.get(wbId) || "";

    let status = "pending";
    const ratingKey = String(rating);
    const modeForRating = replyModes[ratingKey] || "manual";

    if (modeForRating === "auto" && aiDraft) {
      const autoCheck = await canSendReply(userId);
      if (!autoCheck.allowed) {
        status = "pending";
      } else {
        try {
          await sendWBAnswer(WB_API_KEY, wbId, aiDraft);
          status = "auto";
          autoSentCount++;
          if (autoCheck.subscriptionId) {
            await storage.incrementRepliesUsed(autoCheck.subscriptionId);
          }
          if (autoCheck.useLegacy) {
            currentBalance -= 1;
            await storage.updateTokenBalance(userId, currentBalance);
          }
          await delay(350);
        } catch (e: any) {
          console.error(`Auto-reply failed for ${wbId}:`, e);
          errors.push(`Send error for ${wbId}: ${e.message}`);
          status = "pending";
        }
      }
    }

    const usedPhotoAnalysis = !!(aiDraft && photoLinks.length > 0);
    const insertedReview = await storage.insertReview({
      wbId,
      userId,
      cabinetId,
      rating,
      authorName: fb.userName || "Покупатель",
      text: fb.text || null,
      pros: fb.pros || null,
      cons: fb.cons || null,
      productName: fb.productDetails?.productName || fb.subjectName || "Товар",
      productArticle: String(fb.productDetails?.nmId || fb.nmId || ""),
      brandName: reviewBrandName,
      photoLinks: photoLinks,
      hasVideo: hasVideo,
      status,
      aiDraft: aiDraft || null,
      sentAnswer: status === "auto" ? aiDraft : null,
      createdDate: fb.createdDate ? new Date(fb.createdDate) : new Date(),
      usedPhotoAnalysis,
    });

    newCount++;
    if (status === "auto" && insertedReview) {
      await storage.insertTokenTransaction({
        userId, amount: -1, type: "usage",
        description: "Автоответ на отзыв", reviewId: insertedReview.id,
      });
      sendAutoReplyNotification(cabinetId, {
        userName: fb.userName || "Покупатель",
        rating,
        text: fb.text || "",
        productName: fb.productDetails?.productName || fb.subjectName || "Товар",
        productArticle: String(fb.productDetails?.nmId || fb.nmId || ""),
      }, aiDraft).catch(err => console.error("[telegram] auto-reply notification error:", err));
    }

    if (insertedReview && status !== "auto") {
      sendNewReviewNotification(cabinetId, insertedReview.id, {
        userName: fb.userName || "Покупатель",
        rating,
        text: fb.text || "",
        pros: fb.pros || null,
        cons: fb.cons || null,
        productName: fb.productDetails?.productName || fb.subjectName || "Товар",
        productArticle: String(fb.productDetails?.nmId || fb.nmId || ""),
        photoLinks: photoLinks,
        aiInsight: null,
      }).catch(err => console.error("[telegram] new review notification error:", err));
    }
  }

  const pendingReviews = await storage.getPendingReviewsForCabinet(userId, cabinetId);
  if (pendingReviews && pendingReviews.length > 0) {
    for (const pr of pendingReviews) {
      const ratingKey = String(pr.rating);
      const modeForRating = replyModes[ratingKey] || "manual";
      if (modeForRating === "auto" && pr.aiDraft) {
        if (currentBalance < 1) continue;
        try {
          await sendWBAnswer(WB_API_KEY, pr.wbId, pr.aiDraft);
          await storage.updateReview(pr.id, {
            status: "auto",
            sentAnswer: pr.aiDraft,
            updatedAt: new Date(),
          });
          autoSentCount++;
          currentBalance -= 1;
          await storage.updateTokenBalance(userId, currentBalance);
          await storage.insertTokenTransaction({
            userId, amount: -1, type: "usage",
            description: "Автоответ на отзыв", reviewId: pr.id,
          });
          await delay(350);
        } catch (e: any) {
          errors.push(`Auto-retry error for ${pr.wbId}: ${e.message}`);
        }
      }
    }
  }

  const answeredWbIdsToCheck = answeredFeedbacks.map((fb: any) => fb.id).filter(Boolean);
  const existingAnsweredIds = await storage.getExistingReviewWbIds(answeredWbIdsToCheck, userId, cabinetId);

  for (const fb of answeredFeedbacks) {
    const wbId = fb.id;
    if (existingAnsweredIds.has(wbId)) {
      if (fb.answer?.text) {
        const existing = await storage.getReviewByWbId(wbId, userId, cabinetId);
        if (existing && existing.status === "pending") {
          await storage.updateReview(existing.id, {
            status: "answered_externally",
            sentAnswer: fb.answer.text,
            updatedAt: new Date(),
          });
        }
      }
      continue;
    }

    const photoLinks = fb.photoLinks || [];
    const hasVideo = !!(fb.video && (fb.video.link || fb.video.previewImage));
    const reviewBrandName = fb.productDetails?.brandName || "";

    await storage.insertReview({
      wbId,
      userId,
      cabinetId,
      rating: fb.productValuation || 5,
      authorName: fb.userName || "Покупатель",
      text: fb.text || null,
      pros: fb.pros || null,
      cons: fb.cons || null,
      productName: fb.productDetails?.productName || fb.subjectName || "Товар",
      productArticle: String(fb.productDetails?.nmId || fb.nmId || ""),
      brandName: reviewBrandName,
      photoLinks: photoLinks,
      hasVideo: hasVideo,
      status: "answered_externally",
      aiDraft: null,
      sentAnswer: fb.answer?.text || null,
      createdDate: fb.createdDate ? new Date(fb.createdDate) : new Date(),
    });
    importedAnswered++;
  }

  if (importedAnswered > 0) {
    console.log(`[sync-reviews] cabinet=${cabinetId} Imported ${importedAnswered} externally answered reviews`);
  }

  const answeredWbIds = new Set(answeredFeedbacks.map((fb: any) => fb.id));
  const answeredMap = new Map(answeredFeedbacks.map((fb: any) => [fb.id, fb]));
  let externallyAnswered = 0;
  const allPending = await storage.getAllPendingReviewsForCabinet(userId, cabinetId);
  if (allPending && allPending.length > 0) {
    for (const pr of allPending) {
      if (answeredWbIds.has(pr.wbId)) {
        const fb = answeredMap.get(pr.wbId);
        if (fb?.answer?.text) {
          await storage.updateReview(pr.id, {
            status: "answered_externally",
            sentAnswer: fb.answer.text,
            updatedAt: new Date(),
          });
          externallyAnswered++;
        }
      }
    }
    if (externallyAnswered > 0) {
      console.log(`[sync-reviews] cabinet=${cabinetId} Found ${externallyAnswered} pending reviews answered externally`);
    }
  }

  await storage.updateCabinet(cabinetId, { lastSyncAt: new Date() });

  const userSettings = await storage.getSettings(userId);
  if (userSettings) {
    await storage.updateSettings(userSettings.id, { lastSyncAt: new Date() });
  }

  return {
    cabinetId, userId,
    fetched: allFeedbacks.length + answeredFeedbacks.length,
    new: newCount,
    autoSent: autoSentCount,
    importedAnswered,
    externallyAnswered,
    errors: errors.length > 0 ? errors : undefined,
  };
}

function acquireCabinetLock(cabinetId: string): boolean {
  if (cabinetSyncLocks.has(cabinetId)) return false;
  return true;
}

async function withCabinetLock<T>(cabinetId: string, fn: () => Promise<T>): Promise<T> {
  const promise = fn();
  cabinetSyncLocks.set(cabinetId, promise);
  try {
    return await promise;
  } finally {
    cabinetSyncLocks.delete(cabinetId);
  }
}

export async function syncReviews(req: Request, res: Response) {
  try {
    const OPENROUTER_API_KEY = process.env.OPENROUTER_API_KEY;
    if (!OPENROUTER_API_KEY) {
      res.status(503).json({ error: "OPENROUTER_API_KEY не настроен" });
      return;
    }

    const userId = (req as any).userId;

    if (userId) {
      const activeCabinet = await storage.getActiveCabinet(userId);
      if (!activeCabinet?.wbApiKey) {
        res.status(400).json({ error: "WB API ключ не настроен. Добавьте его в настройках." });
        return;
      }

      if (!acquireCabinetLock(activeCabinet.id)) {
        res.status(409).json({ error: "Синхронизация уже выполняется для этого кабинета. Подождите завершения." });
        return;
      }

      const result = await withCabinetLock(activeCabinet.id, () =>
        processCabinetReviews(activeCabinet, OPENROUTER_API_KEY)
      );
      res.json({ success: true, ...result });
    } else {
      console.log("[sync-reviews] Cron mode — processing all cabinets");
      const allCabinets = await storage.getAllCabinetsWithApiKey();
      if (!allCabinets || allCabinets.length === 0) {
        res.json({ success: true, message: "No cabinets to process" });
        return;
      }

      const results: any[] = [];
      await withConcurrencyLimit(allCabinets, 2, async (cabinet) => {
        if (!acquireCabinetLock(cabinet.id)) {
          results.push({ cabinetId: cabinet.id, skipped: true, reason: "sync already in progress" });
          return;
        }
        try {
          const result = await withCabinetLock(cabinet.id, () =>
            processCabinetReviews(cabinet, OPENROUTER_API_KEY)
          );
          results.push(result);
        } catch (e: any) {
          results.push({ cabinetId: cabinet.id, userId: cabinet.userId, error: e.message });
        }
      });
      res.json({ success: true, results });
    }
  } catch (e: any) {
    console.error("sync-reviews error:", e);
    res.status(500).json({ error: e.message });
  }
}

async function processCabinetChats(
  cabinet: { id: string; userId: string; wbApiKey: string | null }
) {
  const userId = cabinet.userId;
  const cabinetId = cabinet.id;
  const WB_API_KEY = cabinet.wbApiKey!;

  const chatsResp = await fetch(`${WB_CHAT_BASE}/api/v1/seller/chats`, {
    headers: { Authorization: WB_API_KEY },
  });
  const rawBody = await chatsResp.text();
  if (!chatsResp.ok) throw new Error(`WB Chats API error ${chatsResp.status}: ${rawBody}`);
  let chatsData: any;
  try { chatsData = JSON.parse(rawBody); } catch { throw new Error(`WB Chats non-JSON: ${rawBody.slice(0, 200)}`); }

  const chatsList = chatsData?.chats || chatsData?.result || [];
  console.log(`[sync-chats] cabinet=${cabinetId} Fetched ${chatsList.length} chats`);

  let upsertedChats = 0;
  let newMessages = 0;
  const errors: string[] = [];
  const chatsWithNewClientMessages = new Set<string>();

  for (const chat of chatsList) {
    const chatId = chat.chatID || chat.chatId;
    if (!chatId) continue;

    try {
      await storage.upsertChat({
        chatId,
        userId,
        cabinetId,
        replySign: chat.replySign || null,
        clientName: chat.userName || chat.clientName || "Покупатель",
        productNmId: chat.nmId || chat.productNmId || null,
        productName: chat.productName || chat.subjectName || "",
      });
      upsertedChats++;
    } catch (e: any) {
      errors.push(`Chat upsert error: ${e.message}`);
    }
  }

  await delay(1000);

  let next = 0;
  let hasMore = true;
  let pagesProcessed = 0;
  const maxPages = 10;

  while (hasMore && pagesProcessed < maxPages) {
    const eventsUrl = `${WB_CHAT_BASE}/api/v1/seller/events${next ? `?next=${next}` : ""}`;
    const eventsResp = await fetch(eventsUrl, { headers: { Authorization: WB_API_KEY } });
    const eventsRaw = await eventsResp.text();
    if (!eventsResp.ok) throw new Error(`WB Events API error ${eventsResp.status}: ${eventsRaw}`);
    let eventsData: any;
    try { eventsData = JSON.parse(eventsRaw); } catch { throw new Error(`WB Events non-JSON: ${eventsRaw.slice(0, 200)}`); }

    const eventsContainer = eventsData?.result || eventsData;
    const events = eventsContainer?.events || [];
    if (events.length === 0) { hasMore = false; break; }

    for (const event of events) {
      const eventId = event.id || event.eventID;
      const chatId = event.chatID || event.chatId;
      if (!eventId || !chatId) continue;

      const chatExists = await storage.getChatByWbId(chatId, userId);
      if (!chatExists) continue;

      const attachments: Array<{ type: string; id: string; name?: string }> = [];
      if (event.file) {
        attachments.push({ type: event.file.type || "file", id: event.file.id || "", name: event.file.name || "" });
      }
      if (event.images && Array.isArray(event.images)) {
        for (const img of event.images) {
          attachments.push({ type: "image", id: img.id || img, name: img.name || "" });
        }
      }

      const sender =
        event.isManager || event.is_manager ||
        event.senderType === "seller" ||
        event.direction === "out" ||
        event.message?.senderType === "seller"
          ? "seller" : "client";

      const msgData = event.message;
      const messageText = typeof msgData === "string" ? msgData : (msgData?.text || event.text || null);
      const sentAt = event.createdAt || event.created_at || new Date().toISOString();

      if (sender === "seller" && messageText) {
        const sentAtMs = new Date(sentAt).getTime();
        const windowStart = new Date(sentAtMs - 120000).toISOString();
        const windowEnd = new Date(sentAtMs + 120000).toISOString();

        const existing = await storage.findDuplicateSellerMessage(chatId, userId, messageText, windowStart, windowEnd);
        if (existing) {
          if (existing.eventId.startsWith("seller_")) {
            await storage.updateChatMessageEventId(existing.id, String(eventId));
          }
          continue;
        }
      }

      try {
        const inserted = await storage.upsertChatMessage({
          chatId,
          userId,
          cabinetId,
          eventId: String(eventId),
          sender,
          text: messageText,
          attachments: attachments.length > 0 ? attachments : [],
          sentAt: new Date(sentAt),
        });
        if (inserted) {
          newMessages++;
          if (sender === "client") chatsWithNewClientMessages.add(chatId);
        }
      } catch (e: any) {
        errors.push(`Message error: ${e.message}`);
      }
    }

    next = eventsContainer?.next || 0;
    hasMore = !!next;
    pagesProcessed++;
    if (hasMore) await delay(1000);
  }

  const allChatsForCabinet = await storage.getChatsByCabinet(userId, cabinetId);
  if (allChatsForCabinet) {
    for (const chat of allChatsForCabinet) {
      const lastMsg = await storage.getLastMessage(chat.chatId, userId);
      if (lastMsg) {
        const updatePayload: Record<string, unknown> = {
          lastMessageText: lastMsg.text || "Вложение",
          lastMessageAt: lastMsg.sentAt,
        };
        if (chatsWithNewClientMessages.has(chat.chatId)) {
          updatePayload.isRead = false;
        }
        await storage.updateChat(chat.chatId, userId, updatePayload);
      }
    }
  }

  return { cabinetId, userId, chats: upsertedChats, messages: newMessages, errors: errors.length > 0 ? errors : undefined };
}

export async function syncChats(req: Request, res: Response) {
  try {
    const userId = (req as any).userId;

    if (userId) {
      const activeCabinet = await storage.getActiveCabinet(userId);
      if (!activeCabinet?.wbApiKey) {
        res.status(400).json({ error: "WB API ключ не настроен. Добавьте его в настройках." });
        return;
      }
      const result = await processCabinetChats(activeCabinet);
      res.json({ success: true, ...result });
    } else {
      console.log("[sync-chats] Cron mode — processing all cabinets");
      const allCabinets = await storage.getAllCabinetsWithApiKey();
      if (!allCabinets || allCabinets.length === 0) {
        res.json({ success: true, message: "No cabinets to process" });
        return;
      }
      const results = [];
      for (const cabinet of allCabinets) {
        try {
          const result = await processCabinetChats(cabinet);
          results.push(result);
        } catch (e: any) {
          results.push({ cabinetId: cabinet.id, userId: cabinet.userId, error: e.message });
        }
      }
      res.json({ success: true, results });
    }
  } catch (e: any) {
    console.error("sync-chats error:", e);
    res.status(500).json({ error: e.message });
  }
}

export async function sendReply(req: Request, res: Response) {
  try {
    const userId = (req as any).userId;
    const replyCheck = await canSendReply(userId);

    if (!replyCheck.allowed) {
      res.status(402).json({ error: replyCheck.error || "Недостаточно токенов." });
      return;
    }

    const { review_id, answer_text } = req.body;
    if (!review_id) {
      res.status(400).json({ error: "review_id is required" });
      return;
    }

    const review = await storage.getReviewById(review_id);
    if (!review || review.userId !== userId) {
      res.status(404).json({ error: "Review not found" });
      return;
    }

    let WB_API_KEY: string | null = null;
    if (review.cabinetId) {
      const cabinet = await storage.getCabinetById(review.cabinetId);
      WB_API_KEY = cabinet?.wbApiKey || null;
    }
    if (!WB_API_KEY) {
      const userSettings = await storage.getSettings(userId);
      WB_API_KEY = userSettings?.wbApiKey || null;
    }
    if (!WB_API_KEY) {
      res.status(400).json({ error: "WB API ключ не настроен. Добавьте его в настройках." });
      return;
    }

    const textToSend = answer_text || review.aiDraft;
    if (!textToSend) {
      res.status(400).json({ error: "No answer text provided" });
      return;
    }

    const resp = await fetch(`${WB_FEEDBACKS_URL}/api/v1/feedbacks/answer`, {
      method: "POST",
      headers: { Authorization: WB_API_KEY, "Content-Type": "application/json" },
      body: JSON.stringify({ id: review.wbId, text: textToSend }),
    });

    if (!resp.ok) {
      const body = await resp.text();
      throw new Error(`WB API error ${resp.status}: ${body}`);
    }

    const isEdited = !!review.sentAnswer;
    await storage.updateReview(review_id, {
      status: "sent",
      sentAnswer: textToSend,
      isEdited,
      updatedAt: new Date(),
    });

    if (replyCheck.subscriptionId) {
      await storage.incrementRepliesUsed(replyCheck.subscriptionId);
    }
    if (replyCheck.useLegacy) {
      const currentBalance = await storage.getTokenBalance(userId);
      await storage.updateTokenBalance(userId, currentBalance - 1);
    }

    await storage.insertTokenTransaction({
      userId,
      amount: -1,
      type: "usage",
      description: "Отправка ответа на отзыв",
      reviewId: review_id,
    });

    res.json({ success: true });
  } catch (e: any) {
    console.error("send-reply error:", e);
    res.status(500).json({ error: e.message });
  }
}

export async function generateReply(req: Request, res: Response) {
  try {
    const OPENROUTER_API_KEY = process.env.OPENROUTER_API_KEY;
    if (!OPENROUTER_API_KEY) {
      res.status(503).json({ error: "OPENROUTER_API_KEY не настроен" });
      return;
    }

    const userId = (req as any).userId;
    const { review_id } = req.body;
    if (!review_id) {
      res.status(400).json({ error: "review_id is required" });
      return;
    }

    const review = await storage.getReviewById(review_id);
    if (!review || review.userId !== userId) {
      res.status(404).json({ error: "Review not found" });
      return;
    }

    const [globalPrompt, globalExamples, globalRules, globalRulesDo, globalRulesDont, globalExamplesV2] = await Promise.all([
      storage.getGlobalSetting("default_prompt"),
      storage.getGlobalSetting("response_examples"),
      storage.getGlobalSetting("rules"),
      storage.getGlobalSetting("rules_do"),
      storage.getGlobalSetting("rules_dont"),
      storage.getGlobalSetting("response_examples_v2"),
    ]);
    let basePrompt = globalPrompt || "Ты — менеджер бренда на Wildberries. Напиши вежливый ответ на отзыв покупателя. 2-4 предложения.";
    let cabinetBrand = "";

    let photoAnalysisEnabled = false;
    if (review.cabinetId) {
      const cabinet = await storage.getCabinetById(review.cabinetId);
      if (cabinet) {
        basePrompt = cabinet.aiPromptTemplate || basePrompt;
        cabinetBrand = cabinet.brandName || "";
        photoAnalysisEnabled = await hasPhotoAnalysisAccess(userId);
      }
    } else {
      const userSettings = await storage.getSettings(userId);
      if (userSettings) {
        basePrompt = userSettings.aiPromptTemplate || basePrompt;
        cabinetBrand = userSettings.brandName || "";
      }
    }

    const promptTemplate = buildFullPrompt(basePrompt, globalExamples, globalRules, globalRulesDo, globalRulesDont, globalExamplesV2, review.rating);

    let recommendationInstruction = "";
    if (review.productArticle && review.cabinetId) {
      const recommendations = await storage.getRecommendationsByArticle(review.productArticle, review.cabinetId);
      if (recommendations && recommendations.length > 0 && review.rating >= 4) {
        const recList = recommendations
          .map((r) => `- Артикул ${r.targetArticle}${r.targetName ? `: "${r.targetName}"` : ""}`)
          .join("\n");
        recommendationInstruction = `\n\nРЕКОМЕНДАЦИИ: В конце ответа ненавязчиво предложи покупателю обратить внимание на другие наши товары:\n${recList}\nУпомяни артикулы, чтобы покупатель мог их найти на WB.`;
      }
    }

    const isEmptyReview = !review.text && !review.pros && !review.cons;
    let emptyInstruction = "";
    if (isEmptyReview) {
      emptyInstruction = review.rating >= 4
        ? `\n\n[Это пустой отзыв без текста. Покупатель поставил только оценку ${review.rating} из 5.\nНапиши КОРОТКУЮ благодарность за отзыв и высокую оценку. Максимум 1-2 предложения.]`
        : `\n\n[Это пустой отзыв без текста. Покупатель поставил низкую оценку ${review.rating} из 5 без пояснения.\nВырази сожаление. Предложи написать в чат с продавцом.\nМаксимум 1-2 предложения.]`;
    }

    const photoLinks = Array.isArray(review.photoLinks) ? review.photoLinks : [];
    const photoCount = photoLinks.length;
    const hasVideo = review.hasVideo === true;
    let attachmentInfo = "";
    if (photoCount > 0 || hasVideo) {
      const parts: string[] = [];
      if (photoCount > 0) {
        const photoWord = photoCount === 1 ? "фотографию" : photoCount < 5 ? "фотографии" : "фотографий";
        parts.push(`${photoCount} ${photoWord}`);
      }
      if (hasVideo) parts.push("видео");
      attachmentInfo = photoCount > 0 && photoAnalysisEnabled
        ? `\n\n[Покупатель приложил ${parts.join(" и ")} к отзыву. Фотографии прикреплены ниже.\nПРАВИЛА АНАЛИЗА ФОТО:\n- Кратко упомяни что видно на фото (например: "Спасибо за фото, видим что товар выглядит отлично!" или "Благодарим за фото")\n- НЕ делай выводов о браке, дефектах или проблемах по фото — качество снимков может быть низким\n- Если на фото товар выглядит хорошо — отметь это положительно\n- Если покупатель в тексте жалуется на проблему — отвечай на текст, а не интерпретируй фото\n- Будь осторожен: блики, тени, сжатие фото могут искажать реальный вид товара]`
        : `\n\n[Покупатель приложил ${parts.join(" и ")} к отзыву. Можешь кратко поблагодарить за фото.]`;
    }

    let reviewContent = "";
    const contentParts: string[] = [];
    if (review.text) contentParts.push(`Комментарий: ${review.text}`);
    if (review.pros) contentParts.push(`Плюсы: ${review.pros}`);
    if (review.cons) contentParts.push(`Недостатки: ${review.cons}`);
    reviewContent = contentParts.length > 0 ? contentParts.join("\n\n") : "(Без текста, только оценка)";

    const authorName = review.authorName || "";
    const nameInstruction = authorName && authorName !== "Покупатель"
      ? `\n\nИмя покупателя: ${authorName}. Обратись к покупателю по имени в ответе.`
      : "";

    const isRefusal = detectRefusal(review.text, review.pros, review.cons);
    const refusalWarning = isRefusal
      ? `\n\n[ВНИМАНИЕ: Покупатель НЕ выкупил товар. НЕ благодари за покупку. Поблагодари за внимание к бренду, вырази сожаление и пригласи вернуться.]`
      : "";

    const brandName = review.brandName || cabinetBrand || "";
    const brandInstruction = brandName
      ? `\n\nНазвание бренда продавца: ${brandName}. Используй это название при обращении к покупателю.`
      : "";

    const userMessage = `ВАЖНО: строго следуй всем правилам из системного промпта.${refusalWarning}${brandInstruction}\n\nОтзыв (${review.rating} из 5 звёзд) на товар "${review.productName}":\n\n${reviewContent}${attachmentInfo}${nameInstruction}${recommendationInstruction}${emptyInstruction}`;

    const sendPhotosToAi = photoCount > 0 && photoAnalysisEnabled;

    const primaryModel = sendPhotosToAi
      ? "openai/gpt-4o"
      : review.rating <= 3
        ? "openai/gpt-4o"
        : "google/gemini-2.0-flash-001";

    const fallbackModels = sendPhotosToAi
      ? ["google/gemini-2.0-flash-001", "anthropic/claude-3.5-sonnet"]
      : primaryModel === "google/gemini-2.0-flash-001"
        ? ["openai/gpt-4o", "anthropic/claude-3.5-sonnet"]
        : ["google/gemini-2.0-flash-001", "anthropic/claude-3.5-sonnet"];

    const modelsToTry = [primaryModel, ...fallbackModels];

    const userContent: any = sendPhotosToAi
      ? [
          { type: "text", text: userMessage },
          ...photoLinks.slice(0, 5).map((photo: any) => ({
            type: "image_url",
            image_url: { url: photo.miniSize || photo.fullSize },
          })).filter((p: any) => p.image_url.url),
        ]
      : userMessage;

    const validPhotos = sendPhotosToAi ? (Array.isArray(userContent) ? userContent.filter((c: any) => c.type === "image_url").length : 0) : 0;
    console.log(`[ai-generate-review] wbId=${review.wbId} model=${primaryModel} photos=${photoCount} photosSent=${validPhotos} photoAnalysis=${photoAnalysisEnabled} rating=${review.rating}`);

    let newDraft = "";
    for (const model of modelsToTry) {
      try {
        const aiResp = await fetch("https://openrouter.ai/api/v1/chat/completions", {
          method: "POST",
          headers: {
            Authorization: `Bearer ${OPENROUTER_API_KEY}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            model,
            messages: [
              { role: "system", content: promptTemplate },
              { role: "user", content: sendPhotosToAi && model !== "openai/gpt-4o" ? userMessage : userContent },
            ],
            max_tokens: isEmptyReview ? 300 : 1000,
            temperature: 0.7,
          }),
        });

        if (!aiResp.ok) {
          const text = await aiResp.text();
          console.warn(`[ai-generate-review] Model ${model} failed (${aiResp.status}): ${text.slice(0, 200)}`);
          continue;
        }

        const aiData = await aiResp.json();
        newDraft = aiData.choices?.[0]?.message?.content || "";
        if (newDraft) {
          if (model !== primaryModel) console.log(`[ai-generate-review] Used fallback model ${model}`);
          break;
        }
      } catch (fetchErr: any) {
        console.warn(`[ai-generate-review] Model ${model} error: ${fetchErr.message}`);
        continue;
      }
    }

    if (!newDraft) throw new Error("All AI models failed to generate response");

    await storage.updateReview(review_id, { aiDraft: newDraft, status: "pending", usedPhotoAnalysis: !!sendPhotosToAi });

    res.json({ success: true, draft: newDraft });
  } catch (e: any) {
    console.error("generate-reply error:", e);
    res.status(500).json({ error: e.message });
  }
}

export async function generateReplyForReview(review: any, cabinet: any): Promise<string | null> {
  try {
    const OPENROUTER_API_KEY = process.env.OPENROUTER_API_KEY;
    if (!OPENROUTER_API_KEY) return null;

    const [globalPrompt, globalExamples, globalRules, globalRulesDo, globalRulesDont, globalExamplesV2] = await Promise.all([
      storage.getGlobalSetting("default_prompt"),
      storage.getGlobalSetting("response_examples"),
      storage.getGlobalSetting("rules"),
      storage.getGlobalSetting("rules_do"),
      storage.getGlobalSetting("rules_dont"),
      storage.getGlobalSetting("response_examples_v2"),
    ]);
    let basePrompt = cabinet?.aiPromptTemplate || globalPrompt ||
      "Ты — менеджер бренда на Wildberries. Напиши вежливый ответ на отзыв покупателя. 2-4 предложения.";
    const cabinetBrand = cabinet?.brandName || "";

    const promptTemplate = buildFullPrompt(basePrompt, globalExamples, globalRules, globalRulesDo, globalRulesDont, globalExamplesV2, review.rating);

    let recommendationInstruction = "";
    if (review.productArticle && review.cabinetId) {
      const recommendations = await storage.getRecommendationsByArticle(review.productArticle, review.cabinetId);
      if (recommendations && recommendations.length > 0 && review.rating >= 4) {
        const recList = recommendations
          .map((r: any) => `- Артикул ${r.targetArticle}${r.targetName ? `: "${r.targetName}"` : ""}`)
          .join("\n");
        recommendationInstruction = `\n\nРЕКОМЕНДАЦИИ: В конце ответа ненавязчиво предложи покупателю обратить внимание на другие наши товары:\n${recList}\nУпомяни артикулы, чтобы покупатель мог их найти на WB.`;
      }
    }

    const isEmptyReview = !review.text && !review.pros && !review.cons;
    let emptyInstruction = "";
    if (isEmptyReview) {
      emptyInstruction = review.rating >= 4
        ? `\n\n[Это пустой отзыв без текста. Покупатель поставил только оценку ${review.rating} из 5.\nНапиши КОРОТКУЮ благодарность за отзыв и высокую оценку. Максимум 1-2 предложения.]`
        : `\n\n[Это пустой отзыв без текста. Покупатель поставил низкую оценку ${review.rating} из 5 без пояснения.\nВырази сожаление. Предложи написать в чат с продавцом.\nМаксимум 1-2 предложения.]`;
    }

    const photoLinks = Array.isArray(review.photoLinks) ? review.photoLinks : [];
    const photoCount = photoLinks.length;
    const hasVideo = review.hasVideo === true;
    const userId = cabinet?.userId || "";
    const photoAnalysisEnabled = userId ? await hasPhotoAnalysisAccess(userId) : false;
    let attachmentInfo = "";
    if (photoCount > 0 || hasVideo) {
      const parts: string[] = [];
      if (photoCount > 0) {
        const photoWord = photoCount === 1 ? "фотографию" : photoCount < 5 ? "фотографии" : "фотографий";
        parts.push(`${photoCount} ${photoWord}`);
      }
      if (hasVideo) parts.push("видео");
      attachmentInfo = photoCount > 0 && photoAnalysisEnabled
        ? `\n\n[Покупатель приложил ${parts.join(" и ")} к отзыву. Фотографии прикреплены ниже.\nПРАВИЛА АНАЛИЗА ФОТО:\n- Кратко упомяни что видно на фото (например: "Спасибо за фото, видим что товар выглядит отлично!" или "Благодарим за фото")\n- НЕ делай выводов о браке, дефектах или проблемах по фото — качество снимков может быть низким\n- Если на фото товар выглядит хорошо — отметь это положительно\n- Если покупатель в тексте жалуется на проблему — отвечай на текст, а не интерпретируй фото\n- Будь осторожен: блики, тени, сжатие фото могут искажать реальный вид товара]`
        : `\n\n[Покупатель приложил ${parts.join(" и ")} к отзыву. Можешь кратко поблагодарить за фото.]`;
    }

    let reviewContent = "";
    const contentParts: string[] = [];
    if (review.text) contentParts.push(`Комментарий: ${review.text}`);
    if (review.pros) contentParts.push(`Плюсы: ${review.pros}`);
    if (review.cons) contentParts.push(`Недостатки: ${review.cons}`);
    reviewContent = contentParts.length > 0 ? contentParts.join("\n\n") : "(Без текста, только оценка)";

    const authorName = review.authorName || "";
    const nameInstruction = authorName && authorName !== "Покупатель"
      ? `\n\nИмя покупателя: ${authorName}. Обратись к покупателю по имени в ответе.`
      : "";

    const isRefusal = detectRefusal(review.text, review.pros, review.cons);
    const refusalWarning = isRefusal
      ? `\n\n[ВНИМАНИЕ: Покупатель НЕ выкупил товар. НЕ благодари за покупку. Поблагодари за внимание к бренду, вырази сожаление и пригласи вернуться.]`
      : "";

    const brandName = review.brandName || cabinetBrand || "";
    const brandInstruction = brandName
      ? `\n\nНазвание бренда продавца: ${brandName}. Используй это название при обращении к покупателю.`
      : "";

    const userMessage = `ВАЖНО: строго следуй всем правилам из системного промпта.${refusalWarning}${brandInstruction}\n\nОтзыв (${review.rating} из 5 звёзд) на товар "${review.productName}":\n\n${reviewContent}${attachmentInfo}${nameInstruction}${recommendationInstruction}${emptyInstruction}`;

    const sendPhotosToAi = photoCount > 0 && photoAnalysisEnabled;

    const primaryModel = sendPhotosToAi
      ? "openai/gpt-4o"
      : review.rating >= 4
        ? "google/gemini-2.0-flash-001"
        : "openai/gpt-4o";

    const fallbackModels = sendPhotosToAi
      ? ["google/gemini-2.0-flash-001", "anthropic/claude-3.5-sonnet"]
      : primaryModel === "google/gemini-2.0-flash-001"
        ? ["openai/gpt-4o", "anthropic/claude-3.5-sonnet"]
        : ["google/gemini-2.0-flash-001", "anthropic/claude-3.5-sonnet"];

    const modelsToTry = [primaryModel, ...fallbackModels];

    const userContent: any = sendPhotosToAi
      ? [
          { type: "text", text: userMessage },
          ...photoLinks.slice(0, 5).map((photo: any) => ({
            type: "image_url",
            image_url: { url: photo.miniSize || photo.fullSize },
          })).filter((p: any) => p.image_url.url),
        ]
      : userMessage;

    const validPhotosGen = sendPhotosToAi ? (Array.isArray(userContent) ? userContent.filter((c: any) => c.type === "image_url").length : 0) : 0;
    console.log(`[ai-generate-reply] reviewId=${review.id} model=${primaryModel} photos=${photoCount} photosSent=${validPhotosGen} photoAnalysis=${photoAnalysisEnabled} rating=${review.rating}`);

    for (const model of modelsToTry) {
      try {
        const aiResp = await fetch("https://openrouter.ai/api/v1/chat/completions", {
          method: "POST",
          headers: {
            Authorization: `Bearer ${OPENROUTER_API_KEY}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            model,
            messages: [
              { role: "system", content: promptTemplate },
              { role: "user", content: sendPhotosToAi && model !== "openai/gpt-4o" ? userMessage : userContent },
            ],
            max_tokens: isEmptyReview ? 300 : 1000,
            temperature: 0.7,
          }),
        });

        if (!aiResp.ok) {
          const text = await aiResp.text();
          console.warn(`[generateReplyForReview] Model ${model} failed (${aiResp.status}): ${text.slice(0, 200)}`);
          continue;
        }

        const aiData = await aiResp.json();
        const result = aiData.choices?.[0]?.message?.content || null;
        if (result && model !== primaryModel) {
          console.log(`[ai-fallback] generateReplyForReview used fallback ${model} (primary ${primaryModel} unavailable)`);
        }
        return result;
      } catch (fetchErr: any) {
        console.warn(`[generateReplyForReview] Model ${model} error: ${fetchErr.message}`);
        continue;
      }
    }

    console.error(`[generateReplyForReview] All models failed for review ${review.id}`);
    return null;
  } catch (e: any) {
    console.error("[generateReplyForReview] Error:", e);
    return null;
  }
}

export async function validateApiKey(req: Request, res: Response) {
  try {
    const userId = (req as any).userId;
    const { api_key, cabinet_id } = req.body;

    if (!api_key || typeof api_key !== "string" || api_key.trim().length < 10) {
      res.json({ valid: false, error: "Некорректный API-ключ" });
      return;
    }
    if (!cabinet_id) {
      res.status(400).json({ valid: false, error: "cabinet_id is required" });
      return;
    }

    const trimmedKey = api_key.trim();

    const testResp = await fetch(
      `${WB_FEEDBACKS_URL}/api/v1/feedbacks?isAnswered=false&take=1&skip=0`,
      { headers: { Authorization: trimmedKey } }
    );

    if (!testResp.ok) {
      await testResp.text();
      if (testResp.status === 401) {
        await storage.updateCabinetApiStatus(cabinet_id, "error_401");
      }
      res.json({
        valid: false,
        error: testResp.status === 401 ? "Неверный API-ключ" : `Ошибка WB API: ${testResp.status}`,
      });
      return;
    }
    await testResp.text();

    await storage.updateCabinet(cabinet_id, { wbApiKey: trimmedKey });
    await storage.updateCabinetApiStatus(cabinet_id, "connected_ok");

    const userSettings = await storage.getSettings(userId);
    if (userSettings) {
      await storage.updateSettings(userSettings.id, { wbApiKey: trimmedKey });
    }

    let chatAccess = false;
    try {
      const chatResp = await fetch(`${WB_CHAT_BASE}/api/v1/seller/chats`, {
        headers: { Authorization: trimmedKey },
      });
      await chatResp.text();
      chatAccess = chatResp.ok;
    } catch { }

    const masked = trimmedKey.length > 8
      ? trimmedKey.slice(0, 4) + "****...****" + trimmedKey.slice(-4)
      : "****";

    let archiveImported = false;
    try {
      const reviewCount = await storage.getReviewCountByCabinet(cabinet_id);
      if (reviewCount === 0) {
        console.log(`First setup detected for cabinet ${cabinet_id} — triggering archive import`);
        fetchArchiveInternal(userId, cabinet_id, trimmedKey).catch(err =>
          console.error("Archive auto-import failed:", err)
        );
        archiveImported = true;
      }
    } catch (archiveErr) {
      console.error("Archive auto-import check failed:", archiveErr);
    }

    res.json({ valid: true, masked_key: masked, chat_access: chatAccess, archive_imported: archiveImported });
  } catch (e: any) {
    console.error("validate-api-key error:", e);
    res.status(500).json({ valid: false, error: e.message });
  }
}

export async function sendChatMessage(req: Request, res: Response) {
  try {
    const userId = (req as any).userId;
    const { chat_id, message } = req.body;

    if (!chat_id) { res.status(400).json({ error: "chat_id is required" }); return; }
    if (!message || !message.trim()) { res.status(400).json({ error: "message is required" }); return; }
    if (message.length > 1000) { res.status(400).json({ error: "Сообщение не должно превышать 1000 символов" }); return; }

    const chat = await storage.getChatByWbId(chat_id, userId);
    if (!chat) { res.status(404).json({ error: "Чат не найден" }); return; }
    if (!chat.replySign) { res.status(400).json({ error: "Нет подписи для ответа (reply_sign). Синхронизируйте чаты." }); return; }

    let WB_API_KEY: string | null = null;
    if (chat.cabinetId) {
      const cabinet = await storage.getCabinetById(chat.cabinetId);
      WB_API_KEY = cabinet?.wbApiKey || null;
    }
    if (!WB_API_KEY) {
      const userSettings = await storage.getSettings(userId);
      WB_API_KEY = userSettings?.wbApiKey || null;
    }
    if (!WB_API_KEY) {
      res.status(400).json({ error: "WB API ключ не настроен. Добавьте его в настройках." });
      return;
    }

    const formData = new FormData();
    formData.append("replySign", chat.replySign);
    formData.append("message", message.trim());

    const resp = await fetch(`${WB_CHAT_BASE}/api/v1/seller/message`, {
      method: "POST",
      headers: { Authorization: WB_API_KEY },
      body: formData,
    });

    if (!resp.ok) {
      const body = await resp.text();
      throw new Error(`WB Chat API error ${resp.status}: ${body}`);
    }

    const eventId = `seller_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;

    try {
      await storage.upsertChatMessage({
        chatId: chat_id,
        userId,
        cabinetId: chat.cabinetId || null,
        eventId,
        sender: "seller",
        text: message.trim(),
        attachments: [],
        sentAt: new Date(),
      });
    } catch (e: any) {
      console.error("Failed to save sent message:", e);
    }

    await storage.updateChat(chat_id, userId, {
      lastMessageText: message.trim(),
      lastMessageAt: new Date(),
    });

    res.json({ success: true });
  } catch (e: any) {
    console.error("send-chat-message error:", e);
    res.status(500).json({ error: e.message });
  }
}

function formatReviewsForAI(reviews: any[]): string {
  return reviews
    .map((r: any, i: number) => {
      const parts = [`${i + 1}. ${r.rating}/5 — ${r.authorName} (${r.createdDate})`];
      if (r.pros) parts.push(`   Плюсы: "${r.pros}"`);
      if (r.cons) parts.push(`   Минусы: "${r.cons}"`);
      if (r.text) parts.push(`   Комментарий: "${r.text}"`);
      parts.push(`   Товар: ${r.productName} (${r.productArticle})`);
      const photos = Array.isArray(r.photoLinks) ? r.photoLinks : [];
      if (photos.length > 0) parts.push(`   Фото: ${photos.length} шт. [photo_review_${i}]`);
      return parts.join("\n");
    })
    .join("\n\n");
}

function collectPhotoUrls(reviews: any[], maxPhotos: number = 20): { url: string; reviewIndex: number; productArticle: string }[] {
  const result: { url: string; reviewIndex: number; productArticle: string }[] = [];
  for (let i = 0; i < reviews.length && result.length < maxPhotos; i++) {
    const r = reviews[i];
    const photos = Array.isArray(r.photoLinks) ? r.photoLinks : [];
    for (const photo of photos) {
      if (result.length >= maxPhotos) break;
      const url = photo.miniSize || photo.fullSize;
      if (url) result.push({ url, reviewIndex: i, productArticle: r.productArticle });
    }
  }
  return result;
}

function detectIntent(message: string): { articles: string[]; wantsNegative: boolean; wantsPositive: boolean } {
  const articleRegex = /\b(\d{6,})\b/g;
  const articles: string[] = [];
  let match;
  while ((match = articleRegex.exec(message)) !== null) {
    articles.push(match[1]);
  }

  const negativeKeywords = [
    "жалоб", "проблем", "негатив", "плох", "минус", "недостат",
    "низк", "ниже 3", "1 звезд", "2 звезд", "3 звезд", "критик",
  ];
  const positiveKeywords = [
    "хвал", "преимущ", "плюс", "достоинств", "лучш", "положительн",
    "высок", "5 звезд", "4 звезд", "нрав",
  ];

  const photoKeywords = [
    "фото", "фотограф", "изображ", "картинк", "снимк", "внешн", "вид товар",
    "упаковк", "дефект", "брак", "как выглядит", "покажи", "визуальн",
  ];

  const lower = message.toLowerCase();
  return {
    articles,
    wantsNegative: negativeKeywords.some((kw) => lower.includes(kw)),
    wantsPositive: positiveKeywords.some((kw) => lower.includes(kw)),
    wantsPhotos: photoKeywords.some((kw) => lower.includes(kw)),
  };
}

async function getTimeStats(userId: string): Promise<string> {
  const allData = await storage.getReviewTimeStats(userId);
  if (allData.length === 0) return "";

  const dayNames = ["Вс", "Пн", "Вт", "Ср", "Чт", "Пт", "Сб"];
  const byDay: Record<string, { total: number; neg: number; sumRating: number }> = {};
  const byHour: Record<number, { total: number; neg: number; sumRating: number }> = {};

  for (const name of dayNames) byDay[name] = { total: 0, neg: 0, sumRating: 0 };
  for (let h = 0; h < 24; h++) byHour[h] = { total: 0, neg: 0, sumRating: 0 };

  for (const r of allData) {
    if (!r.createdDate) continue;
    const d = new Date(r.createdDate);
    const dayName = dayNames[d.getUTCDay()];
    const hour = d.getUTCHours();

    byDay[dayName].total++;
    byDay[dayName].sumRating += r.rating;
    if (r.rating <= 3) byDay[dayName].neg++;

    byHour[hour].total++;
    byHour[hour].sumRating += r.rating;
    if (r.rating <= 3) byHour[hour].neg++;
  }

  const lines: string[] = [];
  lines.push(`Статистика по дням недели (всего ${allData.length} отзывов):`);
  for (const name of ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"]) {
    const d = byDay[name];
    if (d.total === 0) continue;
    const avg = Math.round((d.sumRating / d.total) * 100) / 100;
    lines.push(`  ${name}: ${d.total} отзывов, ср. рейтинг ${avg}, негативных: ${d.neg}`);
  }
  lines.push("");
  lines.push("Статистика по часам (UTC):");
  for (let h = 0; h < 24; h++) {
    const hr = byHour[h];
    if (hr.total === 0) continue;
    const avg = Math.round((hr.sumRating / hr.total) * 100) / 100;
    lines.push(`  ${String(h).padStart(2, "0")}:00-${String(h).padStart(2, "0")}:59: ${hr.total} отзывов, ср. рейтинг ${avg}, негативных: ${hr.neg}`);
  }

  return lines.join("\n");
}

export async function aiAssistant(req: Request, res: Response) {
  try {
    const OPENROUTER_API_KEY = process.env.OPENROUTER_API_KEY;
    if (!OPENROUTER_API_KEY) {
      res.status(503).json({ error: "OPENROUTER_API_KEY не настроен" });
      return;
    }

    const userId = (req as any).userId;
    const { messages } = req.body;

    if (!messages || !Array.isArray(messages) || messages.length === 0) {
      res.status(400).json({ error: "messages array is required" });
      return;
    }

    const hasSubAccess = await hasAiAnalystAccess(userId);
    if (!hasSubAccess) {
      const aiBalance = await storage.getAiRequestBalance(userId);
      if (aiBalance < 1) {
        res.status(402).json({ error: "У вас нет доступа к AI аналитику. Подключите модуль «AI Аналитик» в разделе Тарифы." });
        return;
      }
      await storage.updateAiRequestBalance(userId, aiBalance - 1);
      await storage.insertAiRequestTransaction({
        userId, amount: -1, type: "usage",
        description: "Запрос к AI аналитику",
      });
    }

    const lastUserMessage = [...messages].reverse().find((m: any) => m.role === "user");
    const userText = lastUserMessage?.content || "";
    const { articles, wantsNegative, wantsPositive, wantsPhotos } = detectIntent(userText);

    const allReviews = await storage.getReviewsByUserId(userId);

    interface ProductStats {
      productArticle: string;
      productName: string;
      count: number;
      avgRating: number;
      ratings: Record<number, number>;
      photosCount: number;
    }
    const statsMap = new Map<string, ProductStats>();
    for (const r of allReviews) {
      let s = statsMap.get(r.productArticle);
      if (!s) {
        s = { productArticle: r.productArticle, productName: r.productName, count: 0, avgRating: 0, ratings: { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 }, photosCount: 0 };
        statsMap.set(r.productArticle, s);
      }
      s.count++;
      s.ratings[r.rating] = (s.ratings[r.rating] || 0) + 1;
      const photos = Array.isArray(r.photoLinks) ? r.photoLinks : [];
      if (photos.length > 0) s.photosCount++;
    }
    for (const s of statsMap.values()) {
      const total = Object.entries(s.ratings).reduce((sum, [star, cnt]) => sum + Number(star) * cnt, 0);
      s.avgRating = Math.round((total / s.count) * 100) / 100;
    }

    const productStats = Array.from(statsMap.values());
    const statsBlock = productStats
      .map((s) => `- Артикул ${s.productArticle}: "${s.productName}" — ${s.count} отзывов, средний рейтинг ${s.avgRating} (1: ${s.ratings[1]}, 2: ${s.ratings[2]}, 3: ${s.ratings[3]}, 4: ${s.ratings[4]}, 5: ${s.ratings[5]}), с фото: ${s.photosCount}`)
      .join("\n");

    const timeStatsText = await getTimeStats(userId);

    const contextParts: string[] = [
      `Товары в базе (всего ${productStats.reduce((s, p) => s + p.count, 0)} отзывов):\n${statsBlock}`,
    ];

    if (timeStatsText) contextParts.push(`\n${timeStatsText}`);

    const reviewsWithContext: any[] = [];

    for (const article of articles) {
      const data = await storage.getReviewsByUserIdAndArticle(userId, article, 50);
      if (data && data.length > 0) {
        contextParts.push(`\nОтзывы по артикулу ${article} (последние ${data.length}):\n${formatReviewsForAI(data)}`);
        reviewsWithContext.push(...data);
      } else {
        contextParts.push(`\nАртикул ${article} не найден в базе.`);
      }
    }

    if (wantsNegative && articles.length === 0) {
      const data = await storage.getNegativeReviewsByUserId(userId, 50);
      if (data && data.length > 0) {
        contextParts.push(`\nОтзывы с низким рейтингом (1-3 звезды, последние ${data.length}):\n${formatReviewsForAI(data)}`);
        reviewsWithContext.push(...data);
      }
    }

    if (wantsPositive && articles.length === 0) {
      const data = await storage.getPositiveReviewsByUserId(userId, 50);
      if (data && data.length > 0) {
        contextParts.push(`\nПоложительные отзывы (4-5 звёзд, последние ${data.length}):\n${formatReviewsForAI(data)}`);
        reviewsWithContext.push(...data);
      }
    }

    if (wantsPhotos && reviewsWithContext.length === 0 && articles.length === 0) {
      const allWithPhotos = allReviews.filter((r: any) => {
        const photos = Array.isArray(r.photoLinks) ? r.photoLinks : [];
        return photos.length > 0;
      }).slice(0, 30);
      if (allWithPhotos.length > 0) {
        contextParts.push(`\nОтзывы с фотографиями (${allWithPhotos.length} шт.):\n${formatReviewsForAI(allWithPhotos)}`);
        reviewsWithContext.push(...allWithPhotos);
      }
    }

    const photoUrls = collectPhotoUrls(
      reviewsWithContext.length > 0 ? reviewsWithContext : (wantsPhotos ? allReviews.filter((r: any) => Array.isArray(r.photoLinks) && r.photoLinks.length > 0).slice(0, 20) : []),
      20
    );
    const hasPhotos = photoUrls.length > 0;

    const systemPrompt = `Ты — AI-аналитик по отзывам маркетплейса Wildberries. У тебя есть полный доступ к базе отзывов покупателей.

Твои возможности:
- Анализировать отзывы по конкретным товарам (по артикулу)
- Выявлять основные жалобы и преимущества товаров
- Давать статистику по рейтингам
- Находить паттерны в отзывах
- Анализировать динамику отзывов по дням недели и времени суток
- Выявлять временные паттерны (когда приходит больше негатива, сезонность и т.д.)
- Анализировать фотографии из отзывов: выявлять дефекты, оценивать качество упаковки, внешний вид товара, соответствие описанию
- Сравнивать фото разных отзывов для выявления системных проблем с товаром
- Отвечать на любые вопросы о товарах и мнении покупателей

Правила:
- Отвечай структурированно, используй списки и заголовки
- Приводи конкретные цитаты из отзывов когда это уместно
- Указывай артикулы товаров в ответах
- Если спрашивают о товаре которого нет в базе — скажи об этом
- Отвечай на русском языке
- Будь кратким но информативным
- Используй агрегированную статистику по дням недели и часам для анализа временных паттернов
${hasPhotos ? "- К отзывам приложены фотографии покупателей. Внимательно анализируй их: качество товара, дефекты, упаковку, цвет, внешний вид. Соотноси увиденное на фото с текстом отзыва." : "- Если пользователь хочет анализ фото, предложи указать конкретный артикул товара — тогда ты получишь фотографии из отзывов по этому товару."}

Данные из базы отзывов:

${contextParts.join("\n")}`;

    const aiMessages: any[] = [{ role: "system", content: systemPrompt }];

    const reverseIdx = [...messages].reverse().findIndex((m: any) => m.role === "user");
    const lastUserIdx = reverseIdx >= 0 ? messages.length - 1 - reverseIdx : -1;

    for (let mi = 0; mi < messages.length; mi++) {
      const msg = messages[mi];
      if (mi === lastUserIdx && hasPhotos) {
        const content: any[] = [{ type: "text", text: msg.content }];
        for (const photo of photoUrls) {
          content.push({
            type: "image_url",
            image_url: { url: photo.url },
          });
        }
        aiMessages.push({ role: msg.role, content });
      } else {
        aiMessages.push(msg);
      }
    }

    console.log(`[ai-assistant] userId=${userId} photos=${photoUrls.length} wantsPhotos=${wantsPhotos} articles=${articles.join(",")}`);

    const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${OPENROUTER_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: aiMessages,
        stream: true,
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        res.status(429).json({ error: "Превышен лимит запросов. Попробуйте позже." });
        return;
      }
      const t = await response.text();
      console.error("AI gateway error:", response.status, t);
      res.status(500).json({ error: "Ошибка AI-сервиса" });
      return;
    }

    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");

    const reader = response.body?.getReader();
    if (!reader) {
      res.status(500).json({ error: "No response body" });
      return;
    }

    const decoder = new TextDecoder();
    try {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        res.write(decoder.decode(value, { stream: true }));
      }
    } finally {
      res.end();
    }
  } catch (e: any) {
    console.error("ai-assistant error:", e);
    if (!res.headersSent) {
      res.status(500).json({ error: e.message });
    }
  }
}

export async function createPayment(req: Request, res: Response) {
  try {
    const ROBOKASSA_LOGIN = process.env.ROBOKASSA_LOGIN;
    const ROBOKASSA_PASSWORD1 = process.env.ROBOKASSA_PASSWORD1;

    if (!ROBOKASSA_LOGIN || !ROBOKASSA_PASSWORD1) {
      res.status(503).json({ error: "Оплата пока не настроена. Ключи Робокассы не добавлены." });
      return;
    }

    const userId = (req as any).userId;
    const { amount, tokens, planId, photoAnalysis, aiAnalyst } = req.body;

    let totalAmount = amount;
    let totalTokens = tokens || 0;

    if (planId) {
      const { calculateTotalPrice } = await import("@shared/subscriptionPlans");
      totalAmount = calculateTotalPrice(planId, !!photoAnalysis, !!aiAnalyst);
      if (!totalAmount) {
        res.status(400).json({ error: "Неизвестный тариф" });
        return;
      }
    } else if (!amount || !tokens) {
      res.status(400).json({ error: "amount and tokens are required" });
      return;
    }

    const payment = await storage.createPayment({
      userId,
      amount: String(totalAmount),
      tokens: totalTokens,
      status: "pending",
      planId: planId || null,
      modules: planId ? { photoAnalysis: !!photoAnalysis, aiAnalyst: !!aiAnalyst } : null,
    });

    const outSum = Number(totalAmount).toFixed(2);
    const invId = payment.invId;

    const signatureString = `${ROBOKASSA_LOGIN}:${outSum}:${invId}:${ROBOKASSA_PASSWORD1}`;
    const signature = md5(signatureString);

    const robokassaUrl = `https://auth.robokassa.ru/Merchant/Index.aspx?MerchantLogin=${ROBOKASSA_LOGIN}&OutSum=${outSum}&InvId=${invId}&SignatureValue=${signature}&IsTest=1`;

    console.log(`[create-payment] Created payment inv_id=${invId} for user=${userId}, amount=${outSum}, planId=${planId || 'legacy'}`);

    res.json({ url: robokassaUrl, inv_id: invId });
  } catch (e: any) {
    console.error("create-payment error:", e);
    res.status(500).json({ error: e.message });
  }
}

export async function robokassaWebhook(req: Request, res: Response) {
  try {
    const ROBOKASSA_PASSWORD2 = process.env.ROBOKASSA_PASSWORD2;
    if (!ROBOKASSA_PASSWORD2) {
      res.status(503).send("Configuration error");
      return;
    }

    let outSum: string | undefined;
    let invId: string | undefined;
    let signatureValue: string | undefined;

    const contentType = req.headers["content-type"] || "";
    if (contentType.includes("application/x-www-form-urlencoded")) {
      outSum = req.body.OutSum;
      invId = req.body.InvId;
      signatureValue = req.body.SignatureValue;
    } else if (contentType.includes("application/json")) {
      outSum = req.body.OutSum;
      invId = req.body.InvId;
      signatureValue = req.body.SignatureValue;
    } else {
      outSum = req.query.OutSum as string;
      invId = req.query.InvId as string;
      signatureValue = req.query.SignatureValue as string;
    }

    if (!outSum || !invId || !signatureValue) {
      res.status(400).send("bad request");
      return;
    }

    const expectedSignature = md5(`${outSum}:${invId}:${ROBOKASSA_PASSWORD2}`);
    if (signatureValue.toLowerCase() !== expectedSignature.toLowerCase()) {
      console.error(`[robokassa-webhook] Invalid signature for InvId=${invId}`);
      res.status(400).send("bad sign");
      return;
    }

    const payment = await storage.getPaymentByInvId(Number(invId));
    if (!payment) {
      res.status(404).send("payment not found");
      return;
    }

    if (payment.status === "completed") {
      res.status(200).send(`OK${invId}`);
      return;
    }

    await storage.updatePaymentStatus(payment.id, "completed");

    if (payment.planId) {
      const modules = (payment.modules || {}) as { photoAnalysis?: boolean; aiAnalyst?: boolean };
      const now = new Date();
      const periodEnd = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);
      await storage.createSubscription({
        userId: payment.userId,
        planId: payment.planId,
        status: "active",
        photoAnalysisEnabled: !!modules.photoAnalysis,
        aiAnalystEnabled: !!modules.aiAnalyst,
        currentPeriodStart: now,
        currentPeriodEnd: periodEnd,
        repliesUsedThisPeriod: 0,
      });
      console.log(`[robokassa-webhook] Payment InvId=${invId} completed. Created subscription plan=${payment.planId} for user ${payment.userId}`);
    } else {
      const existingBalance = await storage.getTokenBalance(payment.userId);
      await storage.upsertTokenBalance(payment.userId, existingBalance + payment.tokens);

      await storage.insertTokenTransaction({
        userId: payment.userId,
        amount: payment.tokens,
        type: "purchase",
        description: `Покупка ${payment.tokens} токенов (${outSum} руб)`,
      });
      console.log(`[robokassa-webhook] Payment InvId=${invId} completed. Added ${payment.tokens} tokens to user ${payment.userId}`);
    }

    res.status(200).send(`OK${invId}`);

    processPendingReviews(payment.userId).catch((err) => {
      console.error(`[robokassa-webhook] Error processing pending reviews after payment:`, err);
    });
  } catch (e: any) {
    console.error("robokassa-webhook error:", e);
    res.status(500).send("internal error");
  }
}

async function fetchArchiveInternal(userId: string, cabinetId: string, wbApiKey: string) {
  console.log(`[fetch-archive] Starting archive import for cabinet=${cabinetId} user=${userId}`);

  const allFeedbacks: any[] = [];
  let skip = 0;
  const take = 50;
  const maxPages = 20;
  let pagesProcessed = 0;

  while (pagesProcessed < maxPages) {
    const wbData = await fetchWBArchiveReviews(wbApiKey, skip, take);
    const feedbacks = wbData?.data?.feedbacks || [];
    if (feedbacks.length === 0) break;
    allFeedbacks.push(...feedbacks);
    if (feedbacks.length < take) break;
    skip += take;
    pagesProcessed++;
    await delay(350);
  }

  console.log(`[fetch-archive] Fetched ${allFeedbacks.length} archive reviews`);

  let importedCount = 0;
  let updatedCount = 0;
  for (const fb of allFeedbacks) {
    const wbId = fb.id;
    const wbCreatedDate = fb.createdDate ? new Date(fb.createdDate) : null;
    const existing = await storage.getReviewByWbId(wbId, userId, cabinetId);

    if (existing) {
      if (wbCreatedDate) {
        await storage.updateReview(existing.id, { createdDate: wbCreatedDate });
        updatedCount++;
      }
      continue;
    }

    const photoLinks = fb.photoLinks || [];
    const hasVideo = !!(fb.video && (fb.video.link || fb.video.previewImage));
    const reviewBrandName = fb.productDetails?.brandName || "";
    const answer = fb.answer?.text || null;

    await storage.insertReview({
      wbId,
      userId,
      cabinetId,
      rating: fb.productValuation || 5,
      authorName: fb.userName || "Покупатель",
      text: fb.text || null,
      pros: fb.pros || null,
      cons: fb.cons || null,
      productName: fb.productDetails?.productName || fb.subjectName || "Товар",
      productArticle: String(fb.productDetails?.nmId || fb.nmId || ""),
      brandName: reviewBrandName,
      photoLinks,
      hasVideo,
      status: "archived",
      aiDraft: null,
      sentAnswer: answer,
      createdDate: wbCreatedDate || new Date(),
    });

    importedCount++;
  }

  console.log(`[fetch-archive] Imported ${importedCount}, updated dates for ${updatedCount} archive reviews for cabinet=${cabinetId}`);
  return { imported: importedCount, updated: updatedCount, total: allFeedbacks.length };
}

export async function fetchArchive(req: Request, res: Response) {
  try {
    const userId = (req as any).userId;
    const { cabinet_id } = req.body;

    if (!cabinet_id) {
      res.status(400).json({ error: "cabinet_id is required" });
      return;
    }

    const cabinet = await storage.getCabinetById(cabinet_id);
    if (!cabinet || cabinet.userId !== userId) {
      res.status(404).json({ error: "Cabinet not found" });
      return;
    }
    if (!cabinet.wbApiKey) {
      res.status(400).json({ error: "WB API ключ не настроен для этого кабинета." });
      return;
    }

    const result = await fetchArchiveInternal(userId, cabinet_id, cabinet.wbApiKey);
    res.json({ success: true, ...result });
  } catch (e: any) {
    console.error("fetch-archive error:", e);
    res.status(500).json({ error: e.message });
  }
}

let autoSyncRunning = false;

export async function runAutoSync() {
  if (autoSyncRunning) {
    console.log("[auto-sync] Skipping — previous sync still in progress");
    return;
  }
  autoSyncRunning = true;
  try {
    await runAutoSyncInternal();
  } finally {
    autoSyncRunning = false;
  }
}

async function runAutoSyncInternal() {
  const OPENROUTER_API_KEY = process.env.OPENROUTER_API_KEY;
  const allCabinets = await storage.getAllCabinetsWithApiKey();
  if (!allCabinets || allCabinets.length === 0) return;

  console.log(`[auto-sync] Processing ${allCabinets.length} cabinets`);

  await withConcurrencyLimit(allCabinets, 2, async (cabinet) => {
    if (!acquireCabinetLock(cabinet.id)) {
      console.log(`[auto-sync] Skipping cabinet=${cabinet.id} — sync already in progress`);
      return;
    }

    await withCabinetLock(cabinet.id, async () => {
      try {
        if (OPENROUTER_API_KEY) {
          const reviewResult = await processCabinetReviews(cabinet, OPENROUTER_API_KEY);
          console.log(`[auto-sync] Reviews for cabinet=${cabinet.id}: new=${reviewResult.new}, auto=${reviewResult.autoSent}, imported_answered=${reviewResult.importedAnswered}`);
        }
      } catch (e: any) {
        console.error(`[auto-sync] Review sync failed for cabinet=${cabinet.id}:`, e.message);
      }

      if (OPENROUTER_API_KEY) {
        const aiErrors: string[] = [];
        try {
          const noDraftReviews = await storage.getPendingReviewsWithoutDraft(cabinet.userId, cabinet.id);
          if (noDraftReviews.length > 0) {
            console.log(`[auto-sync] Generating drafts for ${noDraftReviews.length} pending reviews without draft, cabinet=${cabinet.id}`);
            let generated = 0;
            const AI_BATCH_SIZE = 5;
            for (let i = 0; i < noDraftReviews.length; i += AI_BATCH_SIZE) {
              const batch = noDraftReviews.slice(i, i + AI_BATCH_SIZE);
              const results = await Promise.allSettled(
                batch.map(async (review) => {
                  const draft = await generateReplyForReview(review, cabinet);
                  if (draft) {
                    const photoLinks = Array.isArray(review.photoLinks) ? review.photoLinks : [];
                    const usedVision = photoLinks.length > 0 && await hasPhotoAnalysisAccess(cabinet.userId);
                    await storage.updateReview(review.id, { aiDraft: draft, usedPhotoAnalysis: usedVision });
                    return true;
                  }
                  return false;
                })
              );
              for (let j = 0; j < results.length; j++) {
                const r = results[j];
                if (r.status === "fulfilled" && r.value) {
                  generated++;
                } else if (r.status === "rejected") {
                  const review = batch[j];
                  console.error(`[auto-sync] Draft generation failed for review ${review.wbId}:`, r.reason?.message);
                  aiErrors.push(`${review.wbId}: ${r.reason?.message}`);
                }
              }
              await delay(200);
            }
            console.log(`[auto-sync] Generated ${generated}/${noDraftReviews.length} drafts for cabinet=${cabinet.id}`);
          }
        } catch (e: any) {
          console.error(`[auto-sync] Draft backfill failed for cabinet=${cabinet.id}:`, e.message);
          aiErrors.push(`Backfill error: ${e.message}`);
        }

        if (aiErrors.length >= 3) {
          const cabinetName = cabinet.brandName || cabinet.id;
          sendAdminAIErrorNotification(aiErrors.length, cabinetName, aiErrors)
            .catch(err => console.error("[auto-sync] Failed to send AI error notification:", err));
        }
      }

      try {
        const chatResult = await processCabinetChats(cabinet);
        console.log(`[auto-sync] Chats for cabinet=${cabinet.id}: chats=${chatResult.chats}, messages=${chatResult.messages}`);
      } catch (e: any) {
        console.error(`[auto-sync] Chat sync failed for cabinet=${cabinet.id}:`, e.message);
      }
    });
  });

  console.log(`[auto-sync] Completed`);
}

export async function processPendingReviews(userId: string) {
  console.log(`[process-pending] Starting for user=${userId}`);

  const cabinets = await storage.getCabinets(userId);
  if (!cabinets || cabinets.length === 0) {
    console.log(`[process-pending] No cabinets for user=${userId}`);
    return { processed: 0, errors: [] };
  }

  let currentBalance = await storage.getTokenBalance(userId);
  const pendingCheck = await canSendReply(userId);
  if (!pendingCheck.allowed) {
    console.log(`[process-pending] No reply access for user=${userId}`);
    return { processed: 0, errors: [] };
  }

  const defaultModes: Record<string, string> = { "1": "manual", "2": "manual", "3": "manual", "4": "manual", "5": "manual" };
  let totalProcessed = 0;
  const allErrors: string[] = [];

  for (const cabinet of cabinets) {
    if (!cabinet.wbApiKey) continue;

    let cabinetModes = cabinet.replyModes as Record<string, string> | null;
    if (!cabinetModes || Object.keys(cabinetModes).length === 0) {
      const userSettings = await storage.getSettings(userId);
      cabinetModes = (userSettings?.replyModes as Record<string, string>) || null;
    }
    const replyModes = (cabinetModes && Object.keys(cabinetModes).length > 0) ? cabinetModes : defaultModes;

    const pendingReviews = await storage.getPendingReviewsForCabinet(userId, cabinet.id);
    if (!pendingReviews || pendingReviews.length === 0) continue;

    console.log(`[process-pending] cabinet=${cabinet.id} found ${pendingReviews.length} pending reviews, balance=${currentBalance}`);

    for (const pr of pendingReviews) {
      const iterCheck = await canSendReply(userId);
      if (!iterCheck.allowed) break;

      const ratingKey = String(pr.rating);
      const modeForRating = replyModes[ratingKey] || "manual";
      if (modeForRating !== "auto" || !pr.aiDraft) continue;

      try {
        await sendWBAnswer(cabinet.wbApiKey, pr.wbId, pr.aiDraft);
        await storage.updateReview(pr.id, {
          status: "auto",
          sentAnswer: pr.aiDraft,
          updatedAt: new Date(),
        });
        if (iterCheck.subscriptionId) {
          await storage.incrementRepliesUsed(iterCheck.subscriptionId);
        }
        if (iterCheck.useLegacy) {
          currentBalance -= 1;
          await storage.updateTokenBalance(userId, currentBalance);
        }
        await storage.insertTokenTransaction({
          userId, amount: -1, type: "usage",
          description: "Автоответ на отзыв (после пополнения)", reviewId: pr.id,
        });
        totalProcessed++;
        await delay(350);
      } catch (e: any) {
        console.error(`[process-pending] Error for review ${pr.wbId}:`, e.message);
        allErrors.push(`Error for ${pr.wbId}: ${e.message}`);
      }
    }
  }

  console.log(`[process-pending] Done for user=${userId}: processed=${totalProcessed}, errors=${allErrors.length}`);
  return { processed: totalProcessed, errors: allErrors };
}
