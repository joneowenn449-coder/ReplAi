import { useBalance } from "./useBalance";

export function useAiRequestBalance() {
  return useBalance("ai");
}
