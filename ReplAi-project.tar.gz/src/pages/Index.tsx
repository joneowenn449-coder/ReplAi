import { useState, useMemo, useCallback, useEffect, useRef } from "react";
import { Header } from "@/components/Header";
import { ApiStatus } from "@/components/ApiStatus";
import { useChats } from "@/hooks/useChats";
import { StatsCards } from "@/components/StatsCards";
import { FilterTabs } from "@/components/FilterTabs";
import { ReviewCard } from "@/components/ReviewCard";
import { SettingsDialog } from "@/components/SettingsDialog";
import { ChatsSection } from "@/components/ChatsSection";
import { AiAssistant } from "@/components/AiAssistant";
import { DashboardSection } from "@/components/DashboardSection";
import { GuideSection } from "@/components/GuideSection";
import {
  useReviews,
  useReviewCounts,
  useSyncReviews,
  DEFAULT_REPLY_MODES,
  Review,
} from "@/hooks/useReviews";
import { useActiveCabinet } from "@/hooks/useCabinets";
import { format } from "date-fns";
import { ru } from "date-fns/locale";
import { Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";

const PAGE_SIZE = 50;
const VISIBLE = "block";
const HIDDEN = "hidden";

const Index = () => {
  const [activeTab, setActiveTab] = useState("reviews");
  const [activeFilter, setActiveFilter] = useState("all");
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [settingsInitialSection, setSettingsInitialSection] = useState<"telegram" | undefined>(undefined);
  const [syncingCabinetId, setSyncingCabinetId] = useState<string | null>(null);
  const [mountedTabs, setMountedTabs] = useState<Set<string>>(new Set(["reviews"]));
  const [currentPage, setCurrentPage] = useState(0);
  const [accumulatedReviews, setAccumulatedReviews] = useState<Review[]>([]);

  const { data: reviewCounts } = useReviewCounts();
  const { data: pageData, isLoading: reviewsLoading } = useReviews(activeFilter, currentPage, PAGE_SIZE);
  const { data: chats = [] } = useChats();
  const { data: activeCabinet } = useActiveCabinet();
  const syncReviews = useSyncReviews();

  const prevFilterRef = useRef(activeFilter);
  const prevCabinetRef = useRef(activeCabinet?.id);
  useEffect(() => {
    if (prevFilterRef.current !== activeFilter || prevCabinetRef.current !== activeCabinet?.id) {
      setAccumulatedReviews([]);
      setCurrentPage(0);
      prevFilterRef.current = activeFilter;
      prevCabinetRef.current = activeCabinet?.id;
    }
  }, [activeFilter, activeCabinet?.id]);

  useEffect(() => {
    if (!pageData) return;
    if (currentPage === 0) {
      setAccumulatedReviews(pageData);
    } else {
      setAccumulatedReviews(prev => {
        const existingIds = new Set(prev.map(r => r.id));
        const newItems = pageData.filter(r => !existingIds.has(r.id));
        return [...prev, ...newItems];
      });
    }
  }, [pageData, currentPage]);

  const counts = useMemo(() => {
    if (!reviewCounts) return { all: 0, pending: 0, answered: 0, archived: 0 };
    return reviewCounts;
  }, [reviewCounts]);

  const stats = useMemo(() => ({
    pending: counts.pending,
    answered: counts.answered,
    archived: counts.archived,
  }), [counts]);

  const totalForFilter = useMemo(() => {
    if (activeFilter === "all") return counts.all;
    if (activeFilter === "pending") return counts.pending;
    if (activeFilter === "answered") return counts.answered;
    if (activeFilter === "archived") return counts.archived;
    return 0;
  }, [activeFilter, counts]);

  const hasMore = accumulatedReviews.length < totalForFilter;

  const handleTabChange = useCallback((tab: string) => {
    setActiveTab(tab);
    setMountedTabs(prev => {
      if (prev.has(tab)) return prev;
      const next = new Set(prev);
      next.add(tab);
      return next;
    });
  }, []);

  const unreadChatsCount = useMemo(
    () => chats.filter((c) => !c.is_read).length,
    [chats]
  );

  const replyModes = useMemo(
    () => (activeCabinet?.reply_modes as Record<string, "auto" | "manual">) ?? DEFAULT_REPLY_MODES,
    [activeCabinet?.reply_modes]
  );

  const handleSync = useCallback(() => {
    if (!activeCabinet?.id) return;
    setSyncingCabinetId(activeCabinet.id);
    syncReviews.mutate(undefined, {
      onSettled: () => setSyncingCabinetId(null),
      onSuccess: () => {
        setCurrentPage(0);
        setAccumulatedReviews([]);
      },
    });
  }, [activeCabinet?.id, syncReviews]);

  const lastSyncFormatted = useMemo(
    () =>
      activeCabinet?.last_sync_at
        ? format(new Date(activeCabinet.last_sync_at), "d MMM yyyy 'в' HH:mm", { locale: ru })
        : "Ещё не синхронизировано",
    [activeCabinet?.last_sync_at]
  );

  const handleSettingsClick = useCallback(() => {
    setSettingsInitialSection(undefined);
    setSettingsOpen(true);
  }, []);

  const handleTelegramClick = useCallback(() => {
    setSettingsInitialSection("telegram");
    setSettingsOpen(true);
  }, []);

  const handleSettingsChange = useCallback((v: boolean) => {
    setSettingsOpen(v);
    if (!v) setSettingsInitialSection(undefined);
  }, []);

  const handleFilterChange = useCallback((f: string) => {
    setActiveFilter(f);
  }, []);

  const handleShowMore = useCallback(() => {
    setCurrentPage(prev => prev + 1);
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <Header
        activeTab={activeTab}
        onTabChange={handleTabChange}
        onSettingsClick={handleSettingsClick}
        onTelegramClick={handleTelegramClick}
        unreadChatsCount={unreadChatsCount}
      />

      <main className="max-w-6xl mx-auto px-3 sm:px-6 py-4 sm:py-6 space-y-4 sm:space-y-6">
        <div className={activeTab === "reviews" ? VISIBLE : HIDDEN}>
          <div className="space-y-4 sm:space-y-6">
            <ApiStatus
              isConnected={!!activeCabinet?.wb_api_key}
              lastSync={lastSyncFormatted}
              replyModes={replyModes}
              onSync={handleSync}
              isSyncing={syncReviews.isPending && syncingCabinetId === activeCabinet?.id}
            />

            <StatsCards
              pendingCount={stats.pending}
              answeredCount={stats.answered}
            />

            <FilterTabs
              activeFilter={activeFilter}
              onFilterChange={handleFilterChange}
              counts={counts}
            />

            {reviewsLoading && accumulatedReviews.length === 0 ? (
              <div className="flex items-center justify-center py-12">
                <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
              </div>
            ) : (
              <div className="space-y-4">
                {accumulatedReviews.map((review) => (
                  <ReviewCard
                    key={review.id}
                    id={review.id}
                    rating={review.rating}
                    authorName={review.author_name}
                    date={review.created_date}
                    productName={review.product_name}
                    productArticle={review.product_article}
                    status={review.status}
                    photoLinks={review.photo_links}
                    text={review.text}
                    pros={review.pros}
                    cons={review.cons}
                    aiDraft={review.ai_draft}
                    sentAnswer={review.sent_answer}
                    isEdited={review.is_edited}
                    photoAnalysis={activeCabinet?.photo_analysis === true}
                  />
                ))}

                {hasMore && (
                  <div className="flex justify-center pt-2 pb-4">
                    <Button
                      variant="outline"
                      onClick={handleShowMore}
                      disabled={reviewsLoading}
                      data-testid="button-show-more-reviews"
                    >
                      {reviewsLoading ? (
                        <Loader2 className="w-4 h-4 animate-spin mr-2" />
                      ) : null}
                      Показать ещё ({totalForFilter - accumulatedReviews.length} осталось)
                    </Button>
                  </div>
                )}

                {accumulatedReviews.length === 0 && !reviewsLoading && (
                  <div className="text-center py-12 text-muted-foreground">
                    {counts.all === 0
                      ? "Нажмите «Синхронизировать» чтобы загрузить отзывы с WB"
                      : "Нет отзывов в этой категории"}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        {mountedTabs.has("chats") && (
          <div className={activeTab === "chats" ? VISIBLE : HIDDEN}>
            <ChatsSection />
          </div>
        )}

        {mountedTabs.has("ai") && (
          <div className={activeTab === "ai" ? VISIBLE : HIDDEN}>
            <AiAssistant />
          </div>
        )}

        {mountedTabs.has("dashboard") && (
          <div className={activeTab === "dashboard" ? VISIBLE : HIDDEN}>
            <DashboardSection reviews={accumulatedReviews} isLoading={reviewsLoading} />
          </div>
        )}

        {mountedTabs.has("guide") && (
          <div className={activeTab === "guide" ? VISIBLE : HIDDEN}>
            <GuideSection />
          </div>
        )}
      </main>

      <SettingsDialog
        open={settingsOpen}
        onOpenChange={handleSettingsChange}
        initialSection={settingsInitialSection}
      />
    </div>
  );
};

export default Index;
