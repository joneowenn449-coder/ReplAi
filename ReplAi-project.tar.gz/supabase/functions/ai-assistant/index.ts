import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

interface ReviewRow {
  rating: number;
  author_name: string;
  text: string | null;
  pros: string | null;
  cons: string | null;
  product_name: string;
  product_article: string;
  created_date: string;
}

interface ProductStats {
  product_article: string;
  product_name: string;
  count: number;
  avg_rating: number;
  ratings: Record<number, number>;
}

async function getProductStats(supabase: any): Promise<ProductStats[]> {
  const { data: reviews, error } = await supabase
    .from("reviews")
    .select("product_article, product_name, rating")
    .order("created_date", { ascending: false });

  if (error) throw error;

  const statsMap = new Map<string, ProductStats>();
  for (const r of reviews || []) {
    let s = statsMap.get(r.product_article);
    if (!s) {
      s = {
        product_article: r.product_article,
        product_name: r.product_name,
        count: 0,
        avg_rating: 0,
        ratings: { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 },
      };
      statsMap.set(r.product_article, s);
    }
    s.count++;
    s.ratings[r.rating] = (s.ratings[r.rating] || 0) + 1;
  }

  for (const s of statsMap.values()) {
    const total = Object.entries(s.ratings).reduce(
      (sum, [star, cnt]) => sum + Number(star) * cnt,
      0
    );
    s.avg_rating = Math.round((total / s.count) * 100) / 100;
  }

  return Array.from(statsMap.values());
}

async function getReviewsByArticle(
  supabase: any,
  article: string,
  limit = 50
): Promise<ReviewRow[]> {
  const { data, error } = await supabase
    .from("reviews")
    .select("rating, author_name, text, pros, cons, product_name, product_article, created_date")
    .eq("product_article", article)
    .order("created_date", { ascending: false })
    .limit(limit);

  if (error) throw error;
  return data || [];
}

async function getNegativeReviews(
  supabase: any,
  limit = 50
): Promise<ReviewRow[]> {
  const { data, error } = await supabase
    .from("reviews")
    .select("rating, author_name, text, pros, cons, product_name, product_article, created_date")
    .lte("rating", 3)
    .order("created_date", { ascending: false })
    .limit(limit);

  if (error) throw error;
  return data || [];
}

async function getPositiveReviews(
  supabase: any,
  limit = 50
): Promise<ReviewRow[]> {
  const { data, error } = await supabase
    .from("reviews")
    .select("rating, author_name, text, pros, cons, product_name, product_article, created_date")
    .gte("rating", 4)
    .not("pros", "is", null)
    .order("created_date", { ascending: false })
    .limit(limit);

  if (error) throw error;
  return data || [];
}

function formatReviews(reviews: ReviewRow[]): string {
  return reviews
    .map((r, i) => {
      const parts = [`${i + 1}. ⭐ ${r.rating}/5 — ${r.author_name} (${r.created_date})`];
      if (r.pros) parts.push(`   Плюсы: "${r.pros}"`);
      if (r.cons) parts.push(`   Минусы: "${r.cons}"`);
      if (r.text) parts.push(`   Комментарий: "${r.text}"`);
      parts.push(`   Товар: ${r.product_name} (${r.product_article})`);
      return parts.join("\n");
    })
    .join("\n\n");
}

async function getTimeStats(supabase: any, userId: string): Promise<string> {
  // Paginate to bypass 1000-row default limit
  let allData: { created_date: string; rating: number }[] = [];
  const pageSize = 1000;
  let from = 0;
  while (true) {
    const { data, error } = await supabase
      .from("reviews")
      .select("created_date, rating")
      .eq("user_id", userId)
      .range(from, from + pageSize - 1);
    if (error) throw error;
    if (!data || data.length === 0) break;
    allData = allData.concat(data);
    if (data.length < pageSize) break;
    from += pageSize;
  }

  if (allData.length === 0) return "";

  const dayNames = ["Вс", "Пн", "Вт", "Ср", "Чт", "Пт", "Сб"];
  const byDay: Record<string, { total: number; neg: number; sumRating: number }> = {};
  const byHour: Record<number, { total: number; neg: number; sumRating: number }> = {};

  for (const name of dayNames) {
    byDay[name] = { total: 0, neg: 0, sumRating: 0 };
  }
  for (let h = 0; h < 24; h++) {
    byHour[h] = { total: 0, neg: 0, sumRating: 0 };
  }

  for (const r of allData) {
    const d = new Date(r.created_date);
    const dayName = dayNames[d.getUTCDay()];
    const hour = d.getUTCHours();

    byDay[dayName].total++;
    byDay[dayName].sumRating += r.rating;
    if (r.rating <= 3) byDay[dayName].neg++;

    byHour[hour].total++;
    byHour[hour].sumRating += r.rating;
    if (r.rating <= 3) byHour[hour].neg++;
  }

  const lines: string[] = [];
  lines.push(`Статистика по дням недели (всего ${allData.length} отзывов):`);
  for (const name of ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"]) {
    const d = byDay[name];
    if (d.total === 0) continue;
    const avg = Math.round((d.sumRating / d.total) * 100) / 100;
    lines.push(`  ${name}: ${d.total} отзывов, ср. рейтинг ${avg}, негативных: ${d.neg}`);
  }

  lines.push("");
  lines.push("Статистика по часам (UTC):");
  for (let h = 0; h < 24; h++) {
    const hr = byHour[h];
    if (hr.total === 0) continue;
    const avg = Math.round((hr.sumRating / hr.total) * 100) / 100;
    lines.push(`  ${String(h).padStart(2, "0")}:00-${String(h).padStart(2, "0")}:59: ${hr.total} отзывов, ср. рейтинг ${avg}, негативных: ${hr.neg}`);
  }

  return lines.join("\n");
}

function detectIntent(message: string): {
  articles: string[];
  wantsNegative: boolean;
  wantsPositive: boolean;
} {
  const articleRegex = /\b(\d{6,})\b/g;
  const articles: string[] = [];
  let match;
  while ((match = articleRegex.exec(message)) !== null) {
    articles.push(match[1]);
  }

  const negativeKeywords = [
    "жалоб", "проблем", "негатив", "плох", "минус", "недостат",
    "низк", "ниже 3", "1 звезд", "2 звезд", "3 звезд", "критик",
  ];
  const positiveKeywords = [
    "хвал", "преимущ", "плюс", "достоинств", "лучш", "положительн",
    "высок", "5 звезд", "4 звезд", "нрав",
  ];

  const lower = message.toLowerCase();
  const wantsNegative = negativeKeywords.some((kw) => lower.includes(kw));
  const wantsPositive = positiveKeywords.some((kw) => lower.includes(kw));

  return { articles, wantsNegative, wantsPositive };
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { messages } = await req.json();
    if (!messages || !Array.isArray(messages) || messages.length === 0) {
      return new Response(
        JSON.stringify({ error: "messages array is required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const OPENROUTER_API_KEY = Deno.env.get("OPENROUTER_API_KEY");
    if (!OPENROUTER_API_KEY) throw new Error("OPENROUTER_API_KEY is not configured");

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

    // --- Auth & balance check ---
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(
        JSON.stringify({ error: "Unauthorized" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const userSupabase = createClient(supabaseUrl, Deno.env.get("SUPABASE_ANON_KEY")!, {
      global: { headers: { Authorization: authHeader } },
    });

    const token = authHeader.replace("Bearer ", "");
    const { data: claimsData, error: claimsError } = await userSupabase.auth.getClaims(token);
    if (claimsError || !claimsData?.claims) {
      return new Response(
        JSON.stringify({ error: "Unauthorized" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }
    const userId = claimsData.claims.sub as string;

    // Use service role for balance operations
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Check AI request balance
    const { data: aiBalance } = await supabase
      .from("ai_request_balances")
      .select("balance")
      .eq("user_id", userId)
      .maybeSingle();

    if (!aiBalance || aiBalance.balance < 1) {
      return new Response(
        JSON.stringify({ error: "У вас закончились запросы AI аналитика. Приобретите пакет запросов." }),
        { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Deduct 1 request BEFORE streaming
    await supabase
      .from("ai_request_balances")
      .update({ balance: aiBalance.balance - 1, updated_at: new Date().toISOString() })
      .eq("user_id", userId);

    await supabase.from("ai_request_transactions").insert({
      user_id: userId,
      amount: -1,
      type: "usage",
      description: "Запрос к AI аналитику",
    });

    // --- RAG context ---
    const userServiceSupabase = supabase;

    const lastUserMessage = [...messages].reverse().find((m: any) => m.role === "user");
    const userText = lastUserMessage?.content || "";
    const { articles, wantsNegative, wantsPositive } = detectIntent(userText);

    // Fetch product stats for this user
    const { data: allReviews, error: revErr } = await userServiceSupabase
      .from("reviews")
      .select("product_article, product_name, rating")
      .eq("user_id", userId)
      .order("created_date", { ascending: false });

    if (revErr) throw revErr;

    const statsMap = new Map<string, ProductStats>();
    for (const r of allReviews || []) {
      let s = statsMap.get(r.product_article);
      if (!s) {
        s = {
          product_article: r.product_article,
          product_name: r.product_name,
          count: 0,
          avg_rating: 0,
          ratings: { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 },
        };
        statsMap.set(r.product_article, s);
      }
      s.count++;
      s.ratings[r.rating] = (s.ratings[r.rating] || 0) + 1;
    }

    for (const s of statsMap.values()) {
      const total = Object.entries(s.ratings).reduce(
        (sum, [star, cnt]) => sum + Number(star) * cnt,
        0
      );
      s.avg_rating = Math.round((total / s.count) * 100) / 100;
    }

    const productStats = Array.from(statsMap.values());

    const statsBlock = productStats
      .map(
        (s) =>
          `- Артикул ${s.product_article}: "${s.product_name}" — ${s.count} отзывов, средний рейтинг ${s.avg_rating} (★1: ${s.ratings[1]}, ★2: ${s.ratings[2]}, ★3: ${s.ratings[3]}, ★4: ${s.ratings[4]}, ★5: ${s.ratings[5]})`
      )
      .join("\n");

    // Fetch aggregated time stats
    const timeStatsText = await getTimeStats(userServiceSupabase, userId);

    const contextParts: string[] = [
      `Товары в базе (всего ${productStats.reduce((s, p) => s + p.count, 0)} отзывов):\n${statsBlock}`,
    ];

    if (timeStatsText) {
      contextParts.push(`\n${timeStatsText}`);
    }

    for (const article of articles) {
      const { data, error } = await userServiceSupabase
        .from("reviews")
        .select("rating, author_name, text, pros, cons, product_name, product_article, created_date")
        .eq("user_id", userId)
        .eq("product_article", article)
        .order("created_date", { ascending: false })
        .limit(50);
      if (error) throw error;
      if (data && data.length > 0) {
        contextParts.push(
          `\nОтзывы по артикулу ${article} (последние ${data.length}):\n${formatReviews(data)}`
        );
      } else {
        contextParts.push(`\nАртикул ${article} не найден в базе.`);
      }
    }

    if (wantsNegative && articles.length === 0) {
      const { data } = await userServiceSupabase
        .from("reviews")
        .select("rating, author_name, text, pros, cons, product_name, product_article, created_date")
        .eq("user_id", userId)
        .lte("rating", 3)
        .order("created_date", { ascending: false })
        .limit(50);
      if (data && data.length > 0) {
        contextParts.push(
          `\nОтзывы с низким рейтингом (1-3 звезды, последние ${data.length}):\n${formatReviews(data)}`
        );
      }
    }

    if (wantsPositive && articles.length === 0) {
      const { data } = await userServiceSupabase
        .from("reviews")
        .select("rating, author_name, text, pros, cons, product_name, product_article, created_date")
        .eq("user_id", userId)
        .gte("rating", 4)
        .not("pros", "is", null)
        .order("created_date", { ascending: false })
        .limit(50);
      if (data && data.length > 0) {
        contextParts.push(
          `\nПоложительные отзывы (4-5 звёзд, последние ${data.length}):\n${formatReviews(data)}`
        );
      }
    }

    const systemPrompt = `Ты — AI-аналитик по отзывам маркетплейса Wildberries. У тебя есть полный доступ к базе отзывов покупателей.

Твои возможности:
- Анализировать отзывы по конкретным товарам (по артикулу)
- Выявлять основные жалобы и преимущества товаров
- Давать статистику по рейтингам
- Находить паттерны в отзывах
- Анализировать динамику отзывов по дням недели и времени суток
- Выявлять временные паттерны (когда приходит больше негатива, сезонность и т.д.)
- Отвечать на любые вопросы о товарах и мнении покупателей

Правила:
- Отвечай структурированно, используй списки и заголовки
- Приводи конкретные цитаты из отзывов когда это уместно
- Указывай артикулы товаров в ответах
- Если спрашивают о товаре которого нет в базе — скажи об этом
- Отвечай на русском языке
- Будь кратким но информативным
- Используй агрегированную статистику по дням недели и часам для анализа временных паттернов

Данные из базы отзывов:

${contextParts.join("\n")}`;

    const response = await fetch(
      "https://openrouter.ai/api/v1/chat/completions",
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${OPENROUTER_API_KEY}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: "google/gemini-2.5-flash",
          messages: [
            { role: "system", content: systemPrompt },
            ...messages,
          ],
          stream: true,
        }),
      }
    );

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ error: "Превышен лимит запросов. Попробуйте позже." }),
          { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      const t = await response.text();
      console.error("AI gateway error:", response.status, t);
      return new Response(
        JSON.stringify({ error: "Ошибка AI-сервиса" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    return new Response(response.body, {
      headers: { ...corsHeaders, "Content-Type": "text/event-stream" },
    });
  } catch (e) {
    console.error("ai-assistant error:", e);
    return new Response(
      JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
